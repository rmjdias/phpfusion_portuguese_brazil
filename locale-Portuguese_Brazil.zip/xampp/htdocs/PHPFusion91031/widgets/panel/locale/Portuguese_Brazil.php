<?php
$locale['PW_0100'] = "Painel";
$locale['PW_0101'] = "Paineis do PHPFusion";
$locale['PW_0200'] = "Selecionar Painel Instalado";
$locale['PW_0201'] = "Por favor, verifique as configurações de acesso ao painel instaladas no [LINK]Administração do Painel[/LINK]";
$locale['PW_0220'] = "Salvar Painel";
$locale['PW_0221'] = "Salvar e Fechar Painel";
$locale['PW_0222'] = "Nome do arquivo do painel";
