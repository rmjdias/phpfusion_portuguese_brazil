<?php
$locale['f0100'] = "Título";
$locale['f0102'] = "Caminho do Diretório Raiz";
$locale['f0103'] = "Salvar Arquivo";
$locale['f0104'] = "Salvar e Fechar";
$locale['f0105'] = "AVISO: Não foi encontrado arquivo de inclusão";
$locale['f0106'] = "Usar Arquivo Hospedado no Servidor";
$locale['f0107'] = "Widget de Arquivo";
