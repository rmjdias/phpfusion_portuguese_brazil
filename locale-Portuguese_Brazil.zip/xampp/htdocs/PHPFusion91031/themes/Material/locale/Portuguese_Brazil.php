<?php
$locale['material_001'] = 'Pesquisar (mais de 2 caracteres)';
$locale['material_002'] = 'Configurações do tema';
$locale['material_003'] = 'Ocultar barra lateral';
$locale['material_004'] = 'Barra lateral reduzida';
$locale['material_005'] = 'Menu fixo';
$locale['material_006'] = 'Barra lateral fixa';
$locale['material_009'] = 'Mensagens';
$locale['material_010'] = 'Ler';
$locale['material_011'] = 'Nova mensagem';
$locale['material_012'] = 'Não há mensagens';
$locale['material_013'] = 'Criado por';