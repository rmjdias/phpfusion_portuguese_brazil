<?php
$locale['spotlight'] = "Destaque";
$locale['spotlight_search'] = "Pesquisar aplicativos";
$locale['copyright'] = "Direitos autorais &copy; ";
$locale['render_engine'] = "Motor de renderização";
$locale['artemis_admin'] = "Artemis PHP-Fusion 9";
$locale['admin_apps'] = "Aplicativos";
$locale['admin_collapse'] = "Recolher menu";
