<?php
/*
PHP Fusion v.9.30.20
Portuguese_Brazil Language Fileset
Traduzido do Inglês por Romildo José Dias
Email: rmjdias@gmail.com
Web: http://www.
em 18/01/2020
*/
$locale['material_001'] = 'Pesquisa (mais de 2 caracteres)';
$locale['material_002'] = 'Configurações do tema';
$locale['material_003'] = 'Ocultar barra lateral';
$locale['material_004'] = 'Barra lateral pequena';
$locale['material_005'] = 'Menu fixo';
$locale['material_006'] = 'Barra lateral fixa';
$locale['material_009'] = 'Mensagens';
$locale['material_010'] = 'Leitura';
$locale['material_011'] = 'Nova mensagem';
$locale['material_012'] = 'Não há mensagens';
$locale['material_013'] = 'Criado por';
