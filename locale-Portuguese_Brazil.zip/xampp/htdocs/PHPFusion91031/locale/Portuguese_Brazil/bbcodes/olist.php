<?php
$locale['bb_olist_description'] = "Cria uma lista ordenada do tipo especificado";
$locale['bb_olist_usage'] = "Texto 1 :enter: Texto 2 :enter: etc.";
$locale['bb_olist_0100'] = "Lista numérica";
$locale['bb_olist_0101'] = "Letras minúsculas";
$locale['bb_olist_0102'] = "Letras maiúsculas";
$locale['bb_olist_0103'] = "Algarismos romanos (minúsculos)";
$locale['bb_olist_0104'] = "Algarismos romanos (maiúsculos)";
