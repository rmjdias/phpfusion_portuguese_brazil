<?php
$locale['bb_center_description'] = "Alinha o texto selecionado ao centro";
$locale['bb_center_usage'] = "Texto para o centro";
