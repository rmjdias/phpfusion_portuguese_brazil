<?php
$locale['bb_small2_description'] = "Exibe o texto selecionado em um formato pequeno alternativo";
$locale['bb_small2_usage'] = "Texto em formato pequeno alternativo";
