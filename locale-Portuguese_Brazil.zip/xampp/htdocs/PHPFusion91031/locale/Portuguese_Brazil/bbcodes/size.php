<?php
$locale['bb_size_description'] = "Define o tamanho do texto selecionado";
$locale['bb_size_usage'] = "Texto a ser redimensionado";
