<?php
$locale['bb_b_description'] = "Mostra o texto selecionado como negrito";
$locale['bb_b_usage'] = "Texto para Negrito";
