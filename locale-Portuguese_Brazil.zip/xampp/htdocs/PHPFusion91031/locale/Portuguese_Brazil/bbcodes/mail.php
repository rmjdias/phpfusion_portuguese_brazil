<?php
$locale['bb_mail'] = "Endereço de e-mail";
$locale['bb_mail_description'] = "Torna o endereço de e-mail clicável";
$locale['bb_mail_usage'] = "Endereço de e-mail ou texto a ser exibido";
