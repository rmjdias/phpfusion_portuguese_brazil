<?php
$locale['bb_youtube'] = "Vídeo do YouTube";
$locale['bb_youtube_description'] = "Incorporador de vídeos do YouTube";
$locale['bb_youtube_usage'] = "ID do vídeo do YouTube a ser exibido";
