<?php
$locale['bb_i_description'] = "Torna o texto selecionado itálico";
$locale['bb_i_usage'] = "Texto em Itálico";
