<?php
$locale['bb_search_description'] = "Pesquisar o texto informado no site atual";
$locale['bb_search_usage'] = "Texto a pesquisar";
$locale['bb_search_prefix'] = "Pesquisar por ";
$locale['bb_search_suffix'] = " em ";
$locale['bb_search_where'] = "Onde";