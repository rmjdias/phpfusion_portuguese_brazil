<?php
$locale['bb_color_description'] = "Colorir o texto selecionado";
$locale['bb_color_usage'] = "Colorir o texto selecionado";
$locale['bb_color_hex'] = "Valor HEX da cor com hash";
