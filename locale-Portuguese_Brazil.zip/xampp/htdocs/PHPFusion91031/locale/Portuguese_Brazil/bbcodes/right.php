<?php
$locale['bb_right_description'] = "Alinha o texto selecionado à direita";
$locale['bb_right_usage'] = "Texto para alinhar à direita";
