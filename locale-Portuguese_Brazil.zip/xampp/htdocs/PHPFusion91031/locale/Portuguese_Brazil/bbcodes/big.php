<?php
$locale['bb_big_description'] = "Mostrar texto como CAIXA ALTA";
$locale['bb_big_usage'] = "Texto para Caixa Alta";
