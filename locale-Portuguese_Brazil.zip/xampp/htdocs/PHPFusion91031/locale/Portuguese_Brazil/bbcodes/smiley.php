<?php
$locale['bb_smiley_description'] = "Emoticons";
$locale['bb_smiley_usage'] = "Inserir BBCode de emoticon";
