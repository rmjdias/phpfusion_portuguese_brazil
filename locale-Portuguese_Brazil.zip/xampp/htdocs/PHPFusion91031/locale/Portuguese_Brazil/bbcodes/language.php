<?php
$locale['bb_language_description'] = "Exibir o texto selecionado em um idioma específico";
$locale['bb_language_usage'] = "Texto em um idioma específico";
