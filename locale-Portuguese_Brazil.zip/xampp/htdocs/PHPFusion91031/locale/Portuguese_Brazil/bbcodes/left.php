<?php
$locale['bb_left_description'] = "Alinha o texto selecionado à esquerda";
$locale['bb_left_usage'] = "Texto para alinhar à esquerda";
