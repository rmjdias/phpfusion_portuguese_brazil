<?php
$locale['bb_quote_description'] = "Citar texto selecionado";
$locale['bb_quote_usage'] = "Texto a ser citado";
$locale['bb_quote_expand'] = "Ver texto completo";
$locale['bb_quote_collapse'] = "Ocultar texto completo";
$locale['bb_quote'] = "Citar";
$locale['bb_wrote'] = "escreveu";
