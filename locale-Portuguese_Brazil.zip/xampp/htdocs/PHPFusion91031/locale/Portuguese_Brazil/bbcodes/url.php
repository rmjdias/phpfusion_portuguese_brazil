<?php
$locale['bb_url_displayas'] = "Exibir link como";
$locale['bb_url_description'] = "Torna uma URL clicável";
$locale['bb_url_usage'] = "URL";
