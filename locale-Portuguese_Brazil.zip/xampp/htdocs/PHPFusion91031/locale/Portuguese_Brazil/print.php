<?php
//news, articles, blog
$locale['400'] = "Publicado por ";
$locale['401'] = " em ";
$locale['402'] = "Notícias completas";
$locale['403'] = "Blog completo";
//fóruns
$locale['500'] = "Assunto do tópico:";
$locale['501'] = "Publicado por ";
$locale['502'] = " em ";
$locale['503'] = "Editado por ";
//Contrato de Licença
$locale['600'] = "Termos do Contrato";
$locale['601'] = "Última atualização em:";
//Política de Privacidade
$locale['700'] = "Política de Privacidade";
