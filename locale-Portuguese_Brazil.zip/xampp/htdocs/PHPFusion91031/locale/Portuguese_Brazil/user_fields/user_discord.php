<?php
$locale['uf_discord'] = "Discord";
$locale['uf_discord_desc'] = "ID da conta do Discord";
$locale['uf_discord_error'] = "O ID do Discord não pode ficar vazio.";
$locale['uf_discord_error_1'] = "O ID do Discord está incorreto. Por favor, utilize um ID do Discord válido.";
