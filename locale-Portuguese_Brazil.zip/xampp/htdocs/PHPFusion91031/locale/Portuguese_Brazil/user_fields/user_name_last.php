<?php
$locale['uf_name_last'] = "Sobrenome";
$locale['uf_name_last_desc'] = "Sobrenome real do usuário.";
$locale['uf_name_last_error'] = "O sobrenome real do usuário não pode ficar em branco.";
