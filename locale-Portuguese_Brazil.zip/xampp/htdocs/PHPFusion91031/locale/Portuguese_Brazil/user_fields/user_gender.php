<?php
$locale['uf_gender'] = "Gênero";
$locale['uf_gender_desc'] = "O usuário pode especificar o gênero";
$locale['uf_gender_error'] = "O gênero está incorreto ou não foi especificado.";
$locale['uf_gender_00'] = "Não especificado";
$locale['uf_gender_01'] = "Masculino";
$locale['uf_gender_02'] = "Feminino";
$locale['uf_gender_03'] = "Secreto";
