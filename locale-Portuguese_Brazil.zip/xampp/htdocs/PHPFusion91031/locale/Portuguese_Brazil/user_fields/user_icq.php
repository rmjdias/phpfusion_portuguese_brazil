<?php
$locale['uf_icq'] = "ICQ#";
// ICQ é um UIN, não um ID. - https://en.wikipedia.org/wiki/ICQ#UIN
$locale['uf_icq_desc'] = "UIN do ICQ";
$locale['uf_icq_error'] = "O campo ICQ não pode ficar vazio.";
$locale['uf_icq_error_1'] = "UIN do ICQ inválido. Por favor, utilize um Número de Identificação de Usuário (UIN) do ICQ válido.";
