<?php
$locale['uf_psn'] = "PlayStation";
$locale['uf_psn_desc'] = "ID da conta PlayStation";
$locale['uf_psn_error'] = "O ID da conta PlayStation não pode ficar em branco.";
$locale['uf_psn_error_1'] = "O ID da conta PlayStation está incorreto. Por favor, insira um ID válido.";
$locale['uf_psn_placeholder'] = "ID da conta PlayStation";