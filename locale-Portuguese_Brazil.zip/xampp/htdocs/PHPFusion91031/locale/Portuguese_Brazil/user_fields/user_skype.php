<?php
$locale['uf_skype'] = "Skype";
$locale['uf_skype_id'] = "ID do Skype";
$locale['uf_skype_desc'] = "Bate-papo por texto, voz e vídeo no Skype.";
$locale['uf_skype_error'] = "O nome no Skype não pode ficar em branco.";
$locale['uf_skype_error_1'] = "O ID do Skype está incorreto. Por favor, utilize um ID do Skype válido.";
