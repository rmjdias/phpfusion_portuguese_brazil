<?php
$locale['uf_phpfusion'] = "PHPFusion";
$locale['uf_phpfusion_id'] = "Nome de usuário no PHPFusion";
$locale['uf_phpfusion_desc'] = "Conta no site de suporte do PHPFusion";
$locale['uf_phpfusion_error'] = "O nome de usuário no PHPFusion não pode ficar em branco.";
