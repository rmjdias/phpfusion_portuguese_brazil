<?php
$locale['uf_vk'] = "VKontakte";
$locale['uf_vk_desc'] = "Página de perfil no VKontakte";
$locale['uf_vk_error'] = "O ID ou nome de usuário do VKontakte não pode ficar em branco.";
$locale['uf_vk_placeholder'] = "ID ou nome de usuário do VKontakte";
