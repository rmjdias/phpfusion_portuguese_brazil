<?php
$locale['uf_phone_work'] = "Telefone comercial (escritório)";
$locale['uf_phone_work_desc'] = "Número de telefone comercial (escritório) do usuário";
$locale['uf_phone_work_error'] = "O número de telefone comercial (escritório) do usuário não pode ficar em branco.";
