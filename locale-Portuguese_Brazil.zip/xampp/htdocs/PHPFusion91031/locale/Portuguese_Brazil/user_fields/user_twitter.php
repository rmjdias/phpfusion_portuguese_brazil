<?php
$locale['uf_twitter'] = "Twitter";
$locale['uf_twitter_id'] = "Nome de usuário no Twitter";
$locale['uf_twitter_desc'] = "Página de perfil no Twitter";
$locale['uf_twitter_error'] = "O nome de usuário no Twitter não pode ficar em branco.";
$locale['uf_twitter_error_1'] = "O nome de usuário no Twitter é inválido. Por favor, utilize um nome de usuário válido.";
