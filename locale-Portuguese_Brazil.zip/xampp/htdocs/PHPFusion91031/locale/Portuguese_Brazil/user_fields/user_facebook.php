<?php
$locale['uf_facebook'] = "Facebook";
$locale['uf_facebook_desc'] = "Página de perfil do Facebook";
$locale['uf_facebook_error'] = "O nome de usuário do Facebook não pode ficar em branco.";
$locale['uf_facebook_placeholder'] = "Nome de usuário do Facebook";
