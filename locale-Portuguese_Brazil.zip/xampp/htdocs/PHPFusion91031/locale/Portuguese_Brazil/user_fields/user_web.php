<?php
$locale['uf_web'] = "Site";
$locale['uf_web_desc'] = "URL do site";
$locale['uf_web_error'] = "O campo 'Site' não pode ficar vazio.";
$locale['uf_web_001'] = "Visitar";
