<?php
$locale['uf_sig'] = "Assinatura";
$locale['uf_sig_desc'] = "Permite linhas adicionais de texto.";
$locale['uf_sig_error'] = "A assinatura não pode ficar em branco.";
$locale['na'] = "Assinatura não disponível";
