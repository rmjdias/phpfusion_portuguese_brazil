<?php
$locale['uf_linkedin'] = "LinkedIn";
$locale['uf_linkedin_id'] = "Nome de usuário do LinkedIn";
$locale['uf_linkedin_desc'] = "Página de perfil do LinkedIn";
$locale['uf_linkedin_error'] = "O nome de usuário do LinkedIn não pode ficar em branco.";
$locale['uf_linkedin_error_1'] = "O nome de usuário do LinkedIn está incorreto. Por favor, utilize um nome de usuário do LinkedIn válido.";
