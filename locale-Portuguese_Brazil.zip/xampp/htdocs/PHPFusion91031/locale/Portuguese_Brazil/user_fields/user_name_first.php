<?php
$locale['uf_name_first'] = "Nome";
$locale['uf_name_first_desc'] = "Nome real do usuário (João, Maria, etc.).";
$locale['uf_name_first_error'] = "O nome real do usuário não pode ficar em branco.";
