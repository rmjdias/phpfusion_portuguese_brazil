<?php
$locale['uf_blacklist'] = "Lista negra";
$locale['uf_blacklist_desc'] = "Lista negra de usuários (privacidade)";
$locale['uf_blacklist_error'] = "Erro no tipo de dado";
$locale['uf_blacklist_message'] = "Ao bloquear alguém, essa pessoa não poderá mais ver você — incluindo o conteúdo que você publica — nem entrar em contato com você.";
