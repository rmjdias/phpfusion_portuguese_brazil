<?php
$locale['uf_birthdate'] = "Data de nascimento";
$locale['uf_birthdate_date'] = "%d de %B de %Y";
$locale['uf_birthdate_desc'] = "Exibe a data de nascimento do usuário";
$locale['uf_birthdate_error'] = "A data de nascimento não foi definida corretamente.";
