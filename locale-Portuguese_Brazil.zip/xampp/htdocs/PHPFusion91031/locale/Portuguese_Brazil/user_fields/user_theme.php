<?php
$locale['uf_theme'] = "Tema";
$locale['uf_theme_desc'] = "Permite que os usuários escolham seu tema";
$locale['uf_theme_error'] = "O tema não pode ficar vazio.";
