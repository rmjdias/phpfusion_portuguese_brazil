<?php
$locale['uf_vimeo'] = "Vimeo";
$locale['uf_vimeo_desc'] = "ID da conta no Vimeo";
$locale['uf_vimeo_error'] = "O ID do Vimeo não pode ficar vazio.";
$locale['uf_vimeo_error_1'] = "O ID do Vimeo está incorreto. Por favor, utilize um ID do Vimeo válido.";
