<?php
$locale['uf_shouts-stat'] = "Postagens no Shoutbox";
$locale['uf_shouts-stat_desc'] = "Exibe o número de postagens no Shoutbox.";
$locale['uf_shouts-stat_na'] = "Por favor, instale a extensão Shoutbox.";
