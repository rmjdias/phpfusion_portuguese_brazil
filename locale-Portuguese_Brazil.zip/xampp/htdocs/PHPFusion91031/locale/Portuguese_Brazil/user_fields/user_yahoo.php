<?php
$locale['uf_yahoo'] = "Yahoo";
$locale['uf_yahoo_id'] = "ID do Yahoo Instant Messenger";
$locale['uf_yahoo_desc'] = "Yahoo Instant Messenger";
$locale['uf_yahoo_error'] = "O ID do Yahoo não pode ficar em branco.";
$locale['uf_yahoo_error_1'] = "O ID do Yahoo está incorreto. Por favor, utilize um ID do Yahoo válido.";