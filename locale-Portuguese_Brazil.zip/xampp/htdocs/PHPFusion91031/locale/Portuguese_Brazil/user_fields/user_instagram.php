<?php
$locale['uf_instagram'] = "Instagram";
$locale['uf_instagram_desc'] = "Página de perfil do Instagram";
$locale['uf_instagram_error'] = "O nome de usuário do Instagram não pode ficar em branco.";
$locale['uf_instagram_placeholder'] = "Nome de usuário do Instagram";
