<?php
$locale['uf_steam'] = "Steam";
$locale['uf_steam_desc'] = "Página de perfil da Steam";
$locale['uf_steam_error'] = "O nome de usuário da Steam não pode ficar em branco.";
$locale['uf_steam_error_1'] = "O nome de usuário da Steam está incorreto. Por favor, utilize um nome de usuário da Steam válido.";
$locale['uf_steam_placeholder'] = "Nome de usuário da Steam";
