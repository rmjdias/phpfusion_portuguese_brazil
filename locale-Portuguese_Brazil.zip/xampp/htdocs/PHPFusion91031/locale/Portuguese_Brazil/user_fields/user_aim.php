<?php
$locale['uf_aim'] = "ID do AIM";
$locale['uf_aim_desc'] = "AOL Instant Messenger";
$locale['uf_aim_error'] = "O ID do AIM não pode ficar em branco.";
$locale['uf_aim_error_1'] = "O ID do AIM está incorreto. Por favor, utilize um ID do AIM válido.";

