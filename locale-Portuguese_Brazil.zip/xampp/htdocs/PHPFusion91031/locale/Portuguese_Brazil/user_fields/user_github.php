<?php
$locale['uf_github'] = "GitHub";
$locale['uf_github_id'] = "Nome de usuário no GitHub";
$locale['uf_github_desc'] = "Página de perfil no GitHub";
$locale['uf_github_error'] = "O nome de usuário no GitHub não pode ficar em branco.";
