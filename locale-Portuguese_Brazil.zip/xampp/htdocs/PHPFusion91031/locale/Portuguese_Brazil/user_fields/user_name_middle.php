<?php
$locale['uf_name_middle'] = "Nome do meio";
$locale['uf_name_middle_desc'] = "O segundo nome real do usuário.";
$locale['uf_name_middle_error'] = "O segundo nome (nome do meio) não pode ficar em branco.";