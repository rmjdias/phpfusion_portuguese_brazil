<?php
$locale['uf_geo'] = "Geolocalização do usuário";
$locale['uf_geo_desc'] = "País, região, cidade, endereço e CEP obtidos a partir do nosso banco de dados geográficos";
$locale['uf_geo_error'] = "Os campos de geolocalização não podem ficar vazios.";
