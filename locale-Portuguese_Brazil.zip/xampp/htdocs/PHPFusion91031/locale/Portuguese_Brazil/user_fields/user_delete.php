<?php
$locale['uf_delete'] = "Excluir usuário";
$locale['uf_delete_desc'] = "Excluir usuário";
$locale['uf_delete_del'] = "Excluir minha conta";
$locale['uf_delete_exit'] = "Conta excluída...";
