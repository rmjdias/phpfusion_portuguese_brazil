<?php
$locale['uf_whatsapp'] = "ID do WhatsApp";
$locale['uf_whatsapp_desc'] = "Conta do WhatsApp";
$locale['uf_whatsapp_error'] = "O ID do WhatsApp não pode ficar vazio.";
