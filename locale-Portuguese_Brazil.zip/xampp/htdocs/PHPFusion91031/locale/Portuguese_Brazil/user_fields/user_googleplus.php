<?php
$locale['uf_googleplus'] = "Google+";
$locale['uf_googleplus_id'] = "URL ou nome de usuário do perfil no Google+";
$locale['uf_googleplus_desc'] = "Página de perfil no Google+";
$locale['uf_googleplus_error'] = "A URL ou o nome de usuário do perfil no Google+ não pode ficar em branco.";