<?php
$locale['uf_phone_mobile'] = "Telefone celular";
$locale['uf_phone_mobile_desc'] = "Número de telefone celular do usuário";
$locale['uf_phone_mobile_error'] = "O número de telefone celular do usuário não pode ficar em branco.";
