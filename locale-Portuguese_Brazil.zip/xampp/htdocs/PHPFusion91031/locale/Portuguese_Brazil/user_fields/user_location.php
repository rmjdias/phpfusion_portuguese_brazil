<?php
$locale['uf_location'] = "Localização";
$locale['uf_location_desc'] = "País, cidade ou localidade";
$locale['uf_location_error'] = "A localização não pode ficar em branco.";
