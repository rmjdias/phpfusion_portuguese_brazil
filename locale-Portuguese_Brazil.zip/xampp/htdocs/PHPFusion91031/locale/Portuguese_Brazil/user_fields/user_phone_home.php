<?php
$locale['uf_phone_home'] = "Telefone residencial";
$locale['uf_phone_home_desc'] = "Número de telefone residencial (fixo) do usuário";
$locale['uf_phone_home_error'] = "O telefone residencial do usuário não pode ficar em branco.";
