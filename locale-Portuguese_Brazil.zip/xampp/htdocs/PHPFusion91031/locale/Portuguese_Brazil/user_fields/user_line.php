<?php
$locale['uf_line'] = "ID do Line";
$locale['uf_line_desc'] = "Mensageiro instantâneo Line";
$locale['uf_line_error'] = "O ID do Line não pode ficar em branco.";
$locale['uf_line_error_1'] = "O ID do Line está incorreto. Por favor, utilize um ID do Line válido.";
