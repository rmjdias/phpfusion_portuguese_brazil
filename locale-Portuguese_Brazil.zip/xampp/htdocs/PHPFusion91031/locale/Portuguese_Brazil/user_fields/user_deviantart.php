<?php
$locale['uf_da'] = "DeviantArt";
$locale['uf_da_id'] = "Nome de usuário do DeviantArt";
$locale['uf_da_desc'] = "Página de perfil do DeviantArt";
$locale['uf_da_error'] = "Nome de usuário do DeviantArt não pode ser deixado em branco.";
