<?php
$locale['uf_forum-stat'] = "Postagens no fórum";
$locale['uf_forum-stat_desc'] = "Exibe o número de postagens no fórum.";
$locale['uf_forum-stat_na'] = "Por favor, instale a extensão (infusion) de fórum.";
