<?php
$locale['uf_youtube'] = "YouTube";
$locale['uf_youtube_id'] = "URL ou nome de usuário do canal no YouTube";
$locale['uf_youtube_desc'] = "Conta de canal no YouTube";
$locale['uf_youtube_error'] = "A URL ou o nome de usuário do canal no YouTube não pode ficar vazio.";
