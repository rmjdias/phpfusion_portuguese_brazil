<?php
$locale['uf_comments-stat'] = "Comentários publicados";
$locale['uf_comments-stat_desc'] = "Exibe o número de comentários publicados.";
