<?php
/**
* A Microsoft começou a desativar o MSN Messenger (também conhecido como Windows Live Messenger) globalmente em abril de 2013, e o serviço será encerrado definitivamente no dia 31 de outubro.
 * Até essa data, o MSN Messenger permanece disponível apenas na China continental. Em um e-mail sobre as mudanças, a Microsoft sugeriu que os usuários migrassem para o Skype.
 */
$locale['uf_msn'] = "MSN";
$locale['uf_msn_id'] = "Nome de usuário do MSN";
$locale['uf_msn_desc'] = "Microsoft Messenger";
$locale['uf_msn_error'] = "O nome de usuário do MSN não pode ficar em branco.";

