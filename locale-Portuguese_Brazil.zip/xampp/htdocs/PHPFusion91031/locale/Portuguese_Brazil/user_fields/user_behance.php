<?php
$locale['uf_behance'] = "Behance";
$locale['uf_behance_id'] = "Nome de usuário no Behance";
$locale['uf_behance_desc'] = "Página de perfil no Behance";
$locale['uf_behance_error'] = "O nome de usuário no Behance não pode ficar em branco.";
