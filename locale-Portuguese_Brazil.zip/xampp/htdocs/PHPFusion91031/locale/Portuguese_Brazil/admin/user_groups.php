<?php
// Edit/Save/Delete User Group Messages
$locale['GRP_400'] = "Grupo de Usuário atualizado";
$locale['GRP_401'] = "Grupo de Usuário adicionado";
$locale['GRP_403'] = "Usuário não selecionado";
$locale['GRP_404'] = "Sem Grupo ";
$locale['GRP_405'] = "Não é possível excluir o Grupo de Usuários";
$locale['GRP_406'] = "Há usuários assignados a este grupo";
$locale['GRP_407'] = "Grupo de Usuário excluido";
$locale['GRP_408'] = "Nenhum Usuário ou Grupo Seleccionado.";
$locale['GRP_409'] = " Adicionar um grupo de usuário.";

$locale['GRP_410'] = "Usuário \"%s\" adicionado ao grupo \"%s\"";
$locale['GRP_411'] = "Usuário \"%s\" removido do grupo \"%s\"";
$locale['GRP_412'] = "\"%s\" usuários removidos do grupo \"%s\"";

// Edit/Delete Options
$locale['GRP_420'] = "Grupos de Usuário";
$locale['GRP_421'] = "Editar Grupo";
$locale['GRP_422'] = "Apagar Grupo";
$locale['GRP_423'] = "Gestão de Usuários";
$locale['GRP_424'] = "A mostrar o Grupo de Usuários %d.";
$locale['GRP_425'] = "Apagar este grupo de usuários?";
$locale['GRP_426'] = "Grupo Pré-defenido";
$locale['GRP_427'] = "Atualmente %d a mostrar %d usuários.";
$locale['GRP_428'] = "Adicionar Grupo";
$locale['GRP_430'] = "adicionado ao Grupo %s";
// Edit/Add User Group
$locale['GRP_432'] = "Nome do Grupo";
$locale['GRP_433'] = "Descrição do Grupo";
$locale['GRP_434'] = "Salvar Grupo";
$locale['GRP_435'] = "ID";
$locale['GRP_436'] = "Ícone";
$locale['GRP_437'] = "Ação";
$locale['GRP_438'] = "Usuários";
$locale['GRP_439'] = "Ícone de Grupo";
// Search/Add Group Users
$locale['GRP_440'] = "Adicionar usuários ao grupo";
$locale['GRP_441'] = "Pesquisar usuários para adicionar a este grupo usando o formulário abaixo.";
$locale['GRP_442'] = "Você pode procurar por múltiplos usuários separando cada entrada com a tecla Enter.";
$locale['GRP_446'] = "Nome de Usuário";
$locale['GRP_447'] = "Tipo de Usuário";
$locale['GRP_448'] = "Marcar Tudo";
$locale['GRP_449'] = "Desmarcar Tudo";
$locale['GRP_450'] = "Adicionar os usuários selecionados";
$locale['GRP_451'] = "Pesquisar Usuário";
$locale['GRP_452'] = "Grupo atual: ";
// Current Group Users
$locale['GRP_460'] = "Usuários Atuais do Grupo";
$locale['GRP_461'] = "Remover usuários selecionados";
$locale['GRP_462'] = "Remover todos os usuários";
$locale['GRP_463'] = "Não há usuários neste grupo.";
// Error Messages
$locale['GRP_464'] = "Por favor inserir um nome do Grupo";
