<?php
$locale['BBCA_400'] = "BB Codes";
$locale['BBCA_400a'] = "BB Codes Admin";
$locale['BBCA_401'] = "Testar BB Codes";
// Enabled BB Codes
$locale['BBCA_402'] = "BB Code ativado";
$locale['BBCA_403'] = "Nome";
$locale['BBCA_404'] = "Ícone";
$locale['BBCA_405'] = "Descrição";
$locale['BBCA_406'] = "Utilização";
$locale['BBCA_407'] = "Ordem";
$locale['BBCA_408'] = "Para baixo";
$locale['BBCA_409'] = "Para cima";
$locale['BBCA_410'] = "Desativar";
$locale['BBCA_411'] = "Não há códigos BB ativados.";
// Disabled BB Codes
$locale['BBCA_413'] = "Códigos BB desativados";
$locale['BBCA_414'] = "Ativar";
$locale['BBCA_416'] = "Não há códigos BB desativados.";
// Test BB Codes
$locale['BBCA_417'] = "Resultado do Teste de BB Codes";
$locale['BBCA_418'] = "Desativar smileys neste teste";
$locale['BBCA_418a'] = "Testar Mensagem";
$locale['BBCA_418b'] = "Por favor, inserir uma mensagem para testar BB Codes.";
// Notices
$locale['BBCA_430'] = "BB Code foi movido para cima.";
$locale['BBCA_431'] = "BB Code foi movido para baixo.";
$locale['BBCA_432'] = "BB Code foi ativado.";
$locale['BBCA_433'] = "BB Code foi desativado.";
$locale['BBCA_444'] = "BB Code foi atualizado";
$locale['BBCA_445'] = "BB Code não foi atualizado";

$locale['BBCA_500'] = "Adicionar separador";
$locale['BBCA_501'] = "Separador";
$locale['BBCA_502'] = "Separador para agrupar botões BBCode";
