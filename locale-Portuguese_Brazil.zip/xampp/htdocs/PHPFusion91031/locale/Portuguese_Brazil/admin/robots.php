<?php
$locale['ROBOT_400'] = "robots.txt";
$locale['ROBOT_410'] = "Você tem certeza? O arquivo robots.txt será definido como padrão.";
$locale['ROBOT_411'] = "o arquivo robots.txt não existe. Você pode criar este arquivo no diretório raiz.";
$locale['ROBOT_412'] = "arquivo robots.txt atualizado.";
$locale['ROBOT_414'] = "o arquivo robots.txt não tem permissão de escrita.";
$locale['ROBOT_416'] = "arquivo robots.txt criado.";
$locale['ROBOT_417'] = "conteúdo do arquivo robots.txt é incorreto. Por favor, use um conteúdo válido.";
$locale['ROBOT_420'] = "Edite o seu arquivo robots.txt";
$locale['ROBOT_421'] = "[LINK]Você pode encontrar mais informações e ajuda sobre o robots.txt aqui.[/LINK]";
$locale['ROBOT_422'] = "Novo arquivo robots.txt criado";
$locale['ROBOT_423'] = "Repor para valor predefinido";
