<?php
// Section Titles
$locale['PL_400'] = "Links Permanentes Ativados";
$locale['PL_401'] = "Links Permanentes Desativados";
$locale['PL_401a'] = "Definições de Links Permanente";

// Common
$locale['PL_402'] = "Reescrever Nome";
$locale['PL_403'] = "Descrição";
$locale['PL_404'] = "Opções";
$locale['PL_404a'] = "Ativar";
$locale['PL_404b'] = "Desativar";
$locale['PL_404d'] = "Reinstalar";

// Editing Links Permanentes
$locale['PL_405'] = "A editar Links Permanentes para %s";
$locale['PL_406'] = "Etiquetas";
$locale['PL_407'] = "Descrição";
$locale['PL_408'] = "Tipos";
$locale['PL_409'] = "Editar Padrão";
$locale['PL_410'] = "Tipo de Links Permanente %u:";
$locale['PL_411'] = "Erro";
$locale['PL_412'] = "Verifique os arquivos do Links Permanente %s!";
$locale['PL_413'] = "Salvar";
$locale['PL_414'] = "AVISO: Os dados de Links Permanentes &amp; Personalizados serão excluídos permanentemente!<br/>Tem a certeza que deseja desativar este Links Permanente?";
$locale['PL_415'] = "Regras permanentes vão transformar vários URLs de site em URLs amigáveis para mecanismos de busca com opções para personalizar a estrutura de URL para o seu site.<br/>
                  Você pode ativar os Links Permanentes na aba Configurações se o seu servidor suportar mod_rewrite. Você activa os vários Links Permanentes encontrados na guia Desativada. Você pode editar as regras para personalizar ainda mais uma URL de sua preferência diretamente em cada módulo Links Permanente.<br/><br/>
                  Por favor, note que mod_rewrite ou um equivalente é necessário para que os Links Permanentes funcionem.";

// Admin Messages
$locale['PL_420'] = "Ocorreu um erro.";
$locale['PL_421'] = "Links Permanentes atualizados com sucesso.";
$locale['PL_422'] = "Nenhum padrão de Links Permanente encontrado para %s.";
$locale['PL_423'] = "Link permanente não encontrado.";
$locale['PL_424'] = "Links Permanentes ativados para %s com sucesso.";
$locale['PL_425'] = "Links Permanentes para %s já estão ativados.";
$locale['PL_426'] = "Links Permanentes desativados para %s com sucesso.";
$locale['PL_429'] = "Driver de Links Permanente para %s";

// Other
$locale['PL_427'] = "Nenhum Links Permanentes está ativado.";
$locale['PL_428'] = "Links Permanentes";
$locale['seo_htc_warning'] = "Por favor, note que se você alterar quaisquer uma destas configurações, o conteúdo de `.htaccess` será substituído e quaisquer alterações previamente feitas a este arquivo serão perdidas.";
$locale['rewrite_disabled'] = "Parece que `mod_rewrite` não está habilitado em seu host. Ativar as urls SEF pode quebrar seu site. Por favor, entre em contacto com seu provedor de hospedagem sobre como ativar o `mod_rewrite` no seu host.";
