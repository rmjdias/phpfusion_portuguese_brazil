<?php
$locale['IMGUP_100'] = "Gestor de Arquivos Fusion";
// Delete Image
$locale['IMGUP_400'] = "Apagar imagem";
$locale['IMGUP_401'] = "Imagem apagada";
$locale['IMGUP_402'] = "Voltar para a Administração de Imagens";
$locale['IMGUP_403'] = "Voltar ao Índice de Admin";
// Upload Image
$locale['IMGUP_420'] = "Carregar imagem";
$locale['IMGUP_421'] = "Arquivo:";
$locale['IMGUP_422'] = "Imagens Principais";
$locale['IMGUP_423'] = "Imagens do Artigo";
$locale['IMGUP_424'] = "Imagens de Notícias";
$locale['IMGUP_425'] = "Tamanho máx. do arquivo %s / Tipos de arquivo permitidos .jpg,.jpeg,.png,.gif,.bmp,.svg,.tiff,.webp";
$locale['IMGUP_426'] = "Imagem carregada";
$locale['IMGUP_427'] = "Imagens de Categorias de Notícias";
$locale['IMGUP_428'] = "Imagens de Blog";
$locale['IMGUP_429'] = "Imagens de Categorias de Blog";
// View Image
$locale['IMGUP_440'] = "Ver imagem";
$locale['IMGUP_441'] = "Formato de arquivo desconhecido, não é possível exibir a imagem.";
$locale['IMGUP_442'] = "Apagar esta imagem";
// Image Management
$locale['IMGUP_460'] = "Imagens";
$locale['IMGUP_461'] = "Visualizar";
$locale['IMGUP_463'] = "Esta pasta está vazia";
$locale['IMGUP_464'] = "Atualizar lista de imagens para o editor TinyMCE";
$locale['IMGUP_465'] = "Lista de imagens atualizada";
// Popup Error/Warning Messages
$locale['IMGUP_470'] = "Apagar esta imagem?";
