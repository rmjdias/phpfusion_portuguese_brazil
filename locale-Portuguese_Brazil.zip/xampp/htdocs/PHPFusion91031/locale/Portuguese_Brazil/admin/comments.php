<?php
// Comments titles
$locale['C_400'] = "Editar Comentário";
$locale['C_401'] = "Comentários";
// Comments messages
$locale['C_410'] = "Comentário atualizado";
$locale['C_411'] = "Comentário excluido";
$locale['C_412'] = "O comentário foi removido e o usuário, adicionado à lista negra.";
// Edit Comment form
$locale['C_420'] = "Desativar smileys neste comentário";
$locale['C_421'] = "Salvar comentário";
// Comments
$locale['C_431'] = "Delete & Ban";
$locale['C_432'] = "IP do Usuário:";
$locale['C_433'] = "Apagar este comentário?";
$locale['C_434'] = "Não existem comentários para este item.";
$locale['C_435'] = "Você realmente deseja adicionar este usuário a uma lista negra?";
$locale['C_436'] = "Comentário incluído na lista negra.";
// Settings
$locale['C_440'] = "Ativar sistema de comentários?";
$locale['C_441'] = "Permitir que os convidados postem?";
$locale['C_442'] = "Ativar comentários à imagem de perfil?";
$locale['C_443'] = "Comentários Base por Página";
$locale['C_444'] = "Ordenar Comentários";
$locale['C_445'] = "Ascendente";
$locale['C_446'] = "Descendente";
