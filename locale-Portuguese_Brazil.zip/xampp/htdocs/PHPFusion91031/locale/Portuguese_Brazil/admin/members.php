<?php
$locale['ME_400'] = 'Gerenciamento de Usuários';
$locale['ME_401'] = 'Buscar usuário...';
$locale['ME_402'] = 'Filtros de exibição';
$locale['ME_403'] = 'Adicionar um novo usuário';
$locale['ME_404'] = 'Aplicar filtro';
$locale['ME_405'] = 'Nenhum usuário encontrado com os critérios de busca';
//
$locale['ME_407'] = 'A mostrar %s - %d de %d registros encontrados';
$locale['ME_408'] = 'Informação Básica';
$locale['ME_409'] = 'Informação Detalhada';
$locale['ME_410'] = 'Usuário';
$locale['ME_411'] = 'Nível do Usuário';
$locale['ME_412'] = 'Endereço de Email';
$locale['ME_413'] = ' Conta de Usuário';
$locale['ME_414'] = 'Selecionar Tudo';
$locale['ME_415'] = 'Oculto';
$locale['ME_416'] = 'Mostrado';

// Core Fields Filter
$locale['ME_420'] = 'Email Oculto?';
$locale['ME_421'] = 'Data de Adesão';
$locale['ME_422'] = 'Última Sessão';
$locale['ME_423'] = 'Endereço IP';
$locale['ME_424'] = 'Tipo de IP';
$locale['ME_425'] = 'Grupos de Usuários';
$locale['ME_426'] = 'Fuso horário';
$locale['ME_427'] = 'Estado do Usuário';

// Action Form
$locale['ME_430'] = 'Erro: As ações contra os usuários selecionados não puderam ser concluídas';
$locale['ME_431'] = 'Os seguintes usuários serão %s:';
$locale['ME_432'] = '%s foi %s';
$locale['ME_433'] = 'Por favor, especifique um motivo para a ação';
$locale['ME_434'] = 'Motivo';
$locale['ME_435'] = 'Duração';
$locale['ME_436'] = 'Dias';
$locale['ME_437'] = 'Atualizar Usuário';

$locale['ME_450'] = 'Adicionar Novo Usuário';
$locale['ME_451'] = 'Perfil de %s';
$locale['ME_452'] = 'Editar perfil de %s';
$locale['ME_453'] = 'Apagar Usuário %s';
$locale['ME_454'] = "Atenção!";
$locale['ME_455'] = "Você está prestes a excluir o usuário %s!<br/><br/>O conteúdo submetido por este usuário neste site será excluido se você prosseguir.<br/>
A menos que seja um spammer, por exemplo, recomendamos que você bana, suspenda, cancele ou anonimize este usuário.<br/>
Tem a certeza que deseja excluir este usuário?<br/>";
$locale['ME_456'] = 'Apagar Usuário';
$locale['ME_457'] = "Você está prestes a excluir novo usuário inativo %s!<br/>
Tem a certeza que deseja excluir este usuário?<br/>";

$locale['ME_460'] = 'Não há usuário a serem desativados';
$locale['ME_461'] = '%s foi desativado';
$locale['ME_462'] = 'Desativar Usuários Inativos';
$locale['ME_463'] = 'Você tem mais de 50 usuários inativos e terá que executar o processo de desativação (%d) vezes.';
$locale['ME_464'] = '%d usuário(es) não fizeram login por %d dia(s) e foram marcados como inativos. Ao desativar estes usuários eles terão (%d) dia(s) antes de ficarem %s.';
$locale['ME_465'] = 'Por favor, note que alguns usuários podem ter submetido conteúdo para o seu site, tais como mensagens no fórum, comentários, fotografias, etc. Estas serão apagadas quando os usuários desativados forem excluídos.';
$locale['ME_466'] = 'É altamente recomendável alterar a ação de desativação para anonimizar em vez de excluir para evitar a perda de dados!';
$locale['ME_467'] = "Define o sistema de desativação como anonimizante.";
$locale['ME_468'] = 'Desactivação automática de usuários inativos.';
$locale['ME_469'] = 'Este usuário foi ativado';

// Actions
$locale['ME_500'] = 'Banir';
$locale['ME_501'] = 'Reintegrar';
$locale['ME_502'] = 'Desativar';
$locale['ME_503'] = 'Suspender';
$locale['ME_504'] = 'Ban de Segurança';
$locale['ME_505'] = 'Cancelar';
$locale['ME_506'] = 'Anonimizar';
$locale['ME_507'] = 'Ativar';
$locale['ME_508'] = 'Login as User';

// a_message keys
$locale['ME_550'] = 'banido';
$locale['ME_551'] = 'reintegrado';
$locale['ME_552'] = 'desativado';
$locale['ME_553'] = 'suspenso';
$locale['ME_554'] = 'banido por Segurança';
$locale['ME_555'] = 'cancelado';
$locale['ME_556'] = 'anonimizado';
$locale['ME_557'] = 'excluido permanentemente';

$locale['ME_560'] = "Mostrar Resultados";
$locale['ME_561'] = "Mostrar usuário com Status";
$locale['ME_562'] = "Novo usuário inativo";
