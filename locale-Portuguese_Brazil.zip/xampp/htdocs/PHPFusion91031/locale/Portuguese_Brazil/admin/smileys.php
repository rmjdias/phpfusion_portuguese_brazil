<?php
// Smiley titles
$locale['SMLY_400'] = "Smileys atuais";
$locale['SMLY_401'] = "Adicionar Smiley";
$locale['SMLY_402'] = "Editar Smiley";
$locale['SMLY_403'] = "Smileys";
$locale['SMLY_404'] = "Smileys Ativos";
$locale['SMLY_405'] = "Smileys Inativos";
// Smiley messages
$locale['SMLY_410'] = "Smiley adicionado";
$locale['SMLY_411'] = "Smiley atualizado";
$locale['SMLY_412'] = "Smiley excluido";
$locale['SMLY_413'] = "Smileys Inativos";

$locale['SMLY_414'] = "O Texto do Smiley está a ser usado.";
$locale['SMLY_415'] = "O código do Smiley está a ser usado.";
$locale['SMLY_416'] = "Tem a certeza que quer excluir este smiley?";
$locale['SMLY_417'] = "Tem a certeza que quer desativar este smiley?";
$locale['SMLY_418'] = "Erro ao carregar o Smiley";
// Smiley form
$locale['SMLY_420'] = "Código do Smiley:";
$locale['SMLY_421'] = "Imagem do Smiley:";
$locale['SMLY_422'] = "Texto do Smiley:";
$locale['SMLY_423'] = "Salvar Smiley";
$locale['SMLY_424'] = "Atualizar Smiley";
// Current Smileys
$locale['SMLY_430'] = "Código";
$locale['SMLY_431'] = "Imagem";
$locale['SMLY_432'] = "Texto";
$locale['SMLY_433'] = "Opções";
$locale['SMLY_435'] = "Inativo";
$locale['SMLY_436'] = "Não há smileys definidos.";
// Error Message
$locale['SMLY_437'] = "Por favor, insira um Código Smiley";
$locale['SMLY_438'] = "Por favor, seleccione um Smiley";
$locale['SMLY_439'] = "Por favor, insira um Texto Smiley";
$locale['SMLY_440'] = "Não há Smileys ativos";
$locale['SMLY_441'] = "Não há Smileys inativos";
