<?php
$locale['BN_000'] = "Banners";

$locale['BN_012'] = "Banner atualizado na base de dados.";
$locale['BN_013'] = "Banner excluído da base de dados.";
$locale['BN_014'] = "Nenhum banner selecionado.";
$locale['BN_015'] = "Tem a certeza que pretende excluir este banner?";

$locale['sitebanner1'] = "Banner 1";
$locale['sitebanner2'] = "Banner 2";
