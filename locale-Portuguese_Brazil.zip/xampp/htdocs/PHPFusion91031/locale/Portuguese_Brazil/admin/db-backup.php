<?php
// Database Restore
$locale['BACK_400'] = "Restaurar Base de Dados";
$locale['BACK_401'] = "Erro";
$locale['BACK_402'] = "Formato inválido do arquivo de Backup";
$locale['BACK_403'] = "Fechar";
$locale['BACK_404'] = "Database Restore complete";
// Backup File Information
$locale['BACK_410'] = "Informações do Arquivo de Backup";
$locale['BACK_411'] = "Informações do Arquivo de Restauro";
$locale['BACK_412'] = "Arquivo de Backup:";
$locale['BACK_413'] = "Data do Backup:";
$locale['BACK_414'] = "Nome da Base de Dados:";
$locale['BACK_415'] = "Prefixo da Tabela Central:";
$locale['BACK_419'] = "tabelas";
// Database Restore
$locale['BACK_430'] = "Opções do Restauro";
$locale['BACK_431'] = "Arquivo:";
$locale['BACK_432'] = "Data:";
$locale['BACK_433'] = "Criar Tabelas:";
$locale['BACK_434'] = "Popular Tabelas:";
$locale['BACK_435'] = "Selecione:";
$locale['BACK_436'] = "todos";
$locale['BACK_437'] = "nenhum";
$locale['BACK_438'] = "Restaurar";
$locale['BACK_440'] = "Tipos de Arquivos Suportados:";
// Database Backup
$locale['BACK_450'] = "Backup da Base de Dados";
$locale['BACK_451'] = "Informação da Base de Dados";
$locale['BACK_452'] = "Tamanho Total da Tabela:";
$locale['BACK_453'] = "Tamanho Total do Núcleo:";
$locale['BACK_454'] = "Opções de Backup:";
$locale['BACK_455'] = "Tipo de Backup:";
$locale['BACK_456'] = "(comprimido)";
$locale['BACK_457'] = "Tabelas de Base de Dados";
$locale['BACK_458'] = "núcleo";
$locale['BACK_459'] = "Iniciar Backup";
$locale['BACK_460'] = "Senha de Admin:";
$locale['BACK_460b'] = "Por favor inserir a sua Senha de Admin";
$locale['BACK_461'] = "Informação necessária";
// Backup List
$locale['BACK_480'] = "Restaurar Backup";
$locale['BACK_481'] = "Arquivo:";
$locale['BACK_481b'] = "Por favor inserir um nome de arquivo";
