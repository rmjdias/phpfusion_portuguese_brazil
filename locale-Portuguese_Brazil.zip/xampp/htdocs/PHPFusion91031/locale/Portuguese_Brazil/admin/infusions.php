<?php
// Infusion Management
$locale['INF_400'] = "Instalações";
$locale['INF_401'] = "Instalar";
$locale['INF_402'] = "Este item já está instalado";
$locale['INF_403'] = "Este item não pode ser instalado";
$locale['INF_404'] = "Infusões aplicadas";
$locale['INF_405'] = "Título";
$locale['INF_406'] = "Versão";
$locale['INF_407'] = "Desenvolvedor";
$locale['INF_408'] = "Contato";
$locale['INF_409'] = "E-mail";
$locale['INF_410'] = "Web";
$locale['INF_411'] = "Desinstalar";
$locale['INF_412'] = "Desinstalar esta infusão?";
$locale['INF_413'] = "Chave:";
$locale['INF_414'] = "Não instalado";
$locale['INF_415'] = "Instalado";
$locale['INF_416'] = "Atualizar";
$locale['INF_417'] = "Não há infusões disponíveis.";
$locale['INF_418'] = "Estado";
$locale['INF_419'] = "Opções";
$locale['INF_420'] = "Versão";
$locale['INF_421'] = "Autor";
$locale['INF_422'] = "Download de mais Addons";
$locale['INF_423'] = "A infusão %s foi instalada";
$locale['INF_424'] = "A infusão %s foi desinstalada";
