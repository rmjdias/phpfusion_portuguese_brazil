<?php
// Administrators messages
$locale['ADM_400'] = "Administrador Adicionado";
$locale['ADM_401'] = "Administrador atualizado";
$locale['ADM_402'] = "Administrador removido";
// Search/Add Administrator
$locale['ADM_410'] = "Adicionar administrador";
$locale['ADM_411'] = "Pesquisar usuários para adicionar usando o formulário abaixo.";
$locale['ADM_413'] = "Nome de Usuário";
$locale['ADM_415'] = "Aplicar todos os privilégios";
$locale['ADM_416'] = "Tornar Super Administrador";
$locale['ADM_418'] = "Nenhum usuário encontrado.";
$locale['ADM_419'] = "Pesquisar Novamente";
// Current Administrators
$locale['ADM_420'] = "Administradores";
$locale['ADM_421'] = "Nome de Usuário";
$locale['ADM_422'] = "Nível de Admin";
$locale['ADM_423'] = "Opções";
$locale['ADM_425'] = "Sem direitos atribuídos";
// Edit Admin Rights
$locale['ADM_440'] = "Editar Permissões de Admin";
$locale['ADM_441'] = "Administrador de Conteúdo";
$locale['ADM_442'] = "Administrador de Usuários";
$locale['ADM_443'] = "Administrador de Sistema";
$locale['ADM_444'] = "Infusões";
$locale['ADM_445'] = "Marcar todos";
$locale['ADM_448'] = "Salvar Permissões de Admin";
$locale['ADM_449'] = "Definições";
$locale['ADM_450'] = "Verificar segurança";
// Popup Error/Warning Messages
$locale['ADM_460'] = "Excluir este administrador?";
$locale['ADM_461'] = "Adicionar administrador?";
$locale['ADM_462'] = "Dar estes direitos de administrador a um usuário é um risco potencial de segurança!";
$locale['ADM_463'] = "Nenhuma ação selecionada!";
