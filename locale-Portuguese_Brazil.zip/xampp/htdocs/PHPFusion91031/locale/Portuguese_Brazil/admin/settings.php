<?php
$locale['admins_sm_400'] = "Definições";
$locale['admins_401a'] = "Configurações de Hospedagem do Site";
$locale['admins_401b'] = "A configuração para a URL do seu site, a porta do site e os protocolos do site.";

// Site Settings
$locale['admins_401'] = "Geral";
$locale['admins_402'] = "Nome do site";
$locale['admins_403'] = "URL do site";
$locale['admins_404'] = "Logotipo do site";
$locale['admins_405'] = "Endereço de e-mail do site";
$locale['admins_406'] = "Seu nome";
$locale['admins_407'] = "Introdução do Site:";
$locale['admins_408'] = "Deixe vazio se não for necessário";
$locale['admins_409'] = "Descrição do Site:";
$locale['admins_410'] = "Palavras-chave do Site:";
$locale['admins_411'] = "Separe cada palavra com uma vírgula";
$locale['admins_412'] = "Rodapé do Site:";
$locale['admins_413'] = "Página de início do site:";

$locale['admins_415'] = "Coluna Única";
$locale['admins_416'] = "Coluna Dupla";
$locale['admins_417'] = "Idioma do site:";
$locale['admins_418'] = "Tema do site:";
$locale['admins_418a'] = "Tema Administrador do Site:";
$locale['admins_419'] = "Local de pesquisa padrão:";
$locale['admins_419a'] = "Site inteiro";
$locale['admins_420'] = "Excluir painéis à esquerda:";
$locale['admins_421'] = "Excluir painéis superiores:";
$locale['admins_422'] = "Excluir painéis inferiores:";
$locale['admins_423'] = "Excluir painéis à direita:";
$locale['admins_424'] = "Exemplos:<br/>/news.php<br/>/forum/index.php";
$locale['admins_425'] = "Endereço do site";
$locale['admins_426'] = "Protocolo do Site:";
$locale['admins_427'] = "Servidor do Site:";
$locale['admins_428'] = "Exemplo:";
$locale['admins_429'] = "Caminho do Site:";
$locale['admins_430'] = "Porta do Site:";
$locale['admins_430_error'] = "Número de porta do site incorreto";
$locale['admins_430_desc'] = "Deixe em branco para a porta 80";
$locale['admins_431'] = "Pré-visualizar:";
$locale['admins_432'] = "Outras configurações";
$locale['admins_433'] = "mysite.com";
$locale['admins_434'] = "minha pasta";
$locale['admins_435'] = "Excluir Paineis Superiores Acima:";
$locale['admins_436'] = "Excluir Paineis Inferiores Abaixo:";

$locale['admins_438'] = "URLs adequados a motores de busca:";
$locale['admins_439'] = "Normalizar URLs amigáveis:";
$locale['admins_440'] = "Ativar modo de depuração de SEO:";

$locale['admins_443a'] = "Excluir painéis do Usuário 1";
$locale['admins_443b'] = "Excluir painéis do Usuário 2";
$locale['admins_443c'] = "Excluir painéis do Usuário 3";
$locale['admins_443d'] = "Excluir painéis do Usuário 4";
$locale['admins_444'] = "Servidores de domínio";
$locale['admins_444a'] = "Configuração para múltiplos domínios em um único site.<br/><br/> Separe cada domínio por linha (\"enter\")";
$locale['admins_444b'] = "Nomes de domínio registrados <br /> <i>Você deve inserir o domínio atual, conforme indicado em \"Hospedagem do site\" (Site Host), ao ativar este recurso.</i>.";
$locale['admins_445'] = "Inválido (para fins de teste)";
$locale['admins_446'] = "Configurações Gerais";
$locale['admins_447'] = "Configurações de URL";
$locale['admins_448'] = "Configurações de painéis";

// Time & Date Settings
$locale['admins_450'] = "Hora e Data";
$locale['admins_451'] = "Formato de data curto:";
$locale['admins_452'] = "Formato de data longo:";
$locale['admins_453'] = "Formato de data do fórum:";

$locale['admins_455'] = "-- Selecione um Formato --";

$locale['admins_457'] = "Formato de data de Noticias e Artigos:";
$locale['admins_458'] = "Tempo";

$locale['admins_464'] = "Fuso Horário Padrão";
$locale['admins_465'] = "Primeiro dia da semana";

// Registration Settings
$locale['admins_550'] = "Registo";
$locale['admins_551'] = "Ativar sistema de registro?";
$locale['admins_552'] = "Usar verificação de e-mail para registo?";
$locale['admins_553'] = "Mostrar código de validação?";
$locale['admins_557'] = "Novos usuários ativados pelo admin?";
$locale['admins_558'] = "Ativar termos de acordo?";
$locale['admins_559'] = "Termos & Condições";

// Other Settings
$locale['admins_601'] = "Tamanho da miniatura:";
$locale['admins_602'] = "Tamanho da Foto:";
$locale['admins_603'] = "Tamanho máximo da foto:";
$locale['admins_604'] = "Largura x Altura";
$locale['admins_605'] = "Tamanho Máximo de Arquivo (bytes):";
$locale['admins_606'] = "Método de compressão de miniatura";
$locale['admins_607'] = "GD1";
$locale['admins_608'] = "GD2";
$locale['admins_609'] = "Modo de desenvolvimento";
$locale['admins_610'] = "Verificar atualizações";
$locale['admins_611'] = "Delimitador de números";
$locale['admins_612'] = "Separador de milhares";
$locale['admins_613'] = "Licença";

$locale['admins_649'] = "Nomes de usuário proibidos:";
$locale['admins_650'] = "Diversos";
$locale['admins_651'] = "Lista de Palavrões:";
$locale['admins_652'] = "Introduza uma palavra por linha.";
$locale['admins_653'] = "Deixe vazio se não for necessário.";
$locale['admins_654'] = "Substituição de palavrões:";

$locale['admins_657'] = "Modo de Manutenção:";
$locale['admins_658'] = "Mensagem do Modo de Manutenção:";
$locale['admins_659'] = "Filtro de palavrões ativado?";
$locale['admins_660'] = "Intervalo do flooding (segundos):";
$locale['admins_661'] = "Deixe em branco para enviar/descarregar backups imediatamente.";
$locale['admins_662'] = "Editor TinyMCE";

$locale['admins_664'] = "Host SMTP";
$locale['admins_665'] = "Deixe em branco se o sendmail estiver ativado.";
$locale['admins_666'] = "Usuário do SMTP";
$locale['admins_667'] = "Senha de SMTP";
$locale['admins_668'] = "Permitir que os usuários mudem o tema";
$locale['admins_668ML'] = "Tabelas com conteúdo em vários idiomas";
$locale['admins_669ML'] = "Selecione as tabelas que conterão dados em vários idiomas";
$locale['admins_670ML'] = "Artigos";
$locale['admins_671ML'] = "Páginas Personalizadas";
$locale['admins_672ML'] = "Downloads";
$locale['admins_673ML'] = "FAQs";
$locale['admins_674ML'] = "Fórums";
$locale['admins_675ML'] = "Notícias";
$locale['admins_676ML'] = "Galeria de fotos";
$locale['admins_677ML'] = "Votações";
$locale['admins_678ML'] = "Shoutbox";
$locale['admins_679ML'] = "Ligações Web";
$locale['admins_680ML'] = "Links do Site";
$locale['admins_681ML'] = "Paineis";
$locale['admins_682ML'] = "Definições de Idioma";
$locale['admins_683ML'] = "Ativar Sistema Multi-Idioma";
$locale['admins_684ML'] = "Idiomas ativos";
$locale['admins_685ML'] = "Seleção de idiomas permitidos.<br/>ATENÇÃO: Ao remover um idioma, você também remove do sistema todos os links do site, categorias e qualquer outro conteúdo multilíngue personalizados para esse idioma específico.";
$locale['admins_669'] = "Notícias";
$locale['admins_669b'] = "Itens do blog por página";
$locale['admins_669c'] = "Itens de notícias por página";
$locale['admins_670'] = "Deve ser um número ímpar";

$locale['admins_670a'] = "O pacote de idioma %s foi baixado.";
$locale['admins_670b'] = "Pacote de idiomas";
$locale['admins_670c'] = "Transferir";

$locale['admins_672'] = "Ativar o sistema de avaliações?";
$locale['admins_673'] = "Ocultar perfis de usuário do público";
$locale['admins_674'] = "Porta SMTP";
$locale['admins_675'] = "Nível de Manutenção:";
$locale['admins_676'] = "Administradores";
$locale['admins_677'] = "Super Administradores";
$locale['admins_678'] = "Proprietário do Site";
$locale['admins_679'] = "Ativar contador de visitantes?";
$locale['admins_680'] = "Banimento automático por excesso de mensagens (flood)";
$locale['admins_681'] = "Manutenção";
$locale['admins_682'] = "Definições de flood";
$locale['admins_683'] = "Configurações de Segurança";

$locale['admins_687'] = "Palavrões";
$locale['admins_688'] = "Tempo de renderização de exibição";
$locale['admins_689'] = "Sim (todos os visitantes)";
$locale['admins_690'] = "Sim (apenas admins)";
$locale['admins_691'] = "Permitir que os usuários mudem o seu nome de usuário";
$locale['admins_692'] = "Configurações do Captcha";
$locale['admins_693'] = "Captcha";
$locale['admins_694'] = "Permitir Execução do PHP";
$locale['admins_695'] = "AVISO! Permitir a execução de PHP deixará o sistema exposto a vulnerabilidades de SQL.";
$locale['admins_696'] = "Por favor, insira a sua chave reCAPTCHA pública e privada!";

$locale['admins_955'] = "Original";
$locale['admins_956'] = "Quadrado";

$locale['admins_698'] = "Autenticação SMTP?";
$locale['admins_699'] = "Método de Login";
$locale['admins_699b'] = "Ambos";
$locale['admins_699e'] = "E-mail";
$locale['admins_699f'] = "Verificar o tipo MIME dos arquivos carregados?";

$locale['admins_gateway_001'] = "Excluir arquivos temporários";
$locale['admins_gateway_002'] = "Os arquivos temporários do Gateway foram excluídos.";

// Private Message Settings
$locale['admins_700'] = "Mensagens Privadas";
$locale['admins_701'] = "Limite da caixa de entrada:";
$locale['admins_702'] = "Limite da caixa de saída:";
$locale['admins_703'] = "Limite de arquivamento:";
$locale['admins_704'] = "Definir como 0 para ilimitado";
$locale['admins_707'] = "Limites de Mensagens Privadas";
$locale['admins_708'] = "Valores padrão para as opções de usuário";
$locale['admins_709'] = "Notificações de email?";
$locale['admins_710'] = "Salvar PMs enviados?";
$locale['admins_711'] = "Nota: As opções de usuário individuais têm precedência se estiverem definidas. Se nenhuma opção de usuário estiver definida, então as opções globais são aplicadas.";
$locale['admins_712'] = "As mensagens foram excluídas.";
$locale['admins_713'] = "Tem certeza de que deseja excluir todas as mensagens privadas?";
$locale['admins_714'] = "Excluir mensagens";

// Save Settings
$locale['admins_750'] = "Salvar Definições";

// Other Settings
$locale['admins_800'] = "Limpar fóruns";
$locale['admins_801'] = "Posts excluídos: ";
$locale['admins_802'] = "Tópicos excluídos: ";
$locale['admins_803'] = "Anexos excluídos: ";

// Privacy policy
$locale['admins_820'] = "Política de Privacidade";

// Banners Settings
$locale['admins_850'] = "Banners";
$locale['admins_851'] = "Banner 1";
$locale['admins_852'] = "Banner 2";
$locale['admins_853'] = "Senha de Admin:";
$locale['admins_854'] = "Gravar Banner";
$locale['admins_855'] = "Pré-visualizar Banners";

// Settings Error
$locale['admins_900'] = "Configuração atualizada com sucesso";
$locale['admins_901'] = "Ocorreu um erro de atualização da base de dados: As configurações não foram atualizadas!";
$locale['admins_902'] = "O host do site não pode ser deixado em branco!";

// User Management
$locale['admins_1001'] = "Taxa de Imagem de Perfil:";
$locale['admins_1002'] = "Sistema de desativação ativado";
$locale['admins_1003'] = "Período permitido para inatividade:";
$locale['admins_1004'] = "Número de dias inativos antes que a desativação seja iniciada.";
$locale['admins_1005'] = "Resposta antes da ação de desativação:";
$locale['admins_1006'] = "Número de dias para responder ao e-mail de notificação de desativação.";
$locale['admins_1007'] = "Definições de perfil de usuário";
$locale['admins_1008'] = "Tamanho da Imagem de Perfil:";
$locale['admins_1009'] = "Largura x Altura";
$locale['admins_1010'] = "Tamanho Máximo de Arquivo (bytes):";
$locale['admins_1011'] = "Ação de desativação:";
$locale['admins_1012'] = "Anonimizar Usuários";
$locale['admins_1013'] = "Apagar Usuários";
$locale['admins_1014'] = "Os usuários podem iniciar sessão a partir de diferentes dispositivos simultaneamente?";
$locale['admins_1014a'] = "Desativar para melhor segurança";
$locale['admins_1015'] = "Largura";
$locale['admins_1016'] = "Altura";

$locale['admins_1020'] = [1 => 'Bytes (bytes)', 1024 => 'KB (Kilobytes)', 1048576 => 'MB (Megabytes)'];

// Social integration
$locale['admins_1030'] = "Crie meta tags OpenGraph para redes sociais";
$locale['admins_1031'] = "Permitir URLs de índice em BB Codes";
$locale['admins_1032'] = "Permitir a indexação de URLs em perfis de usuário";

$locale['admins_blog_description'] = "Configurações do sistema de blog";
$locale['admins_news_description'] = "Configurações do sistema de notícias";
$locale['admins_forum_description'] = "Configurações do sistema de fórum";
$locale['admins_download_description'] = "Configurações do sistema de downloads";
$locale['admins_language_description'] = "Configurações do sistema de idiomas";
$locale['admins_photo_description'] = "Configurações do sistema de galeria de fotos";
$locale['admins_main_description'] = "Configurações do sistema principal";
$locale['admins_misc_description'] = "Configurações de diversos componentes centrais";
$locale['admins_message_description'] = "Configurações do sistema de mensagens privadas";
$locale['admins_register_description'] = "Configurações do sistema de registro de usuários";
$locale['admins_security_description'] = "Configurações do sistema de segurança";
$locale['admins_time_description'] = "Configurações de data e hora do servidor";
$locale['admins_user_description'] = "Configurações do sistema de gerenciamento de usuários";
$locale['admins_theme_description'] = "As configurações para temas";
$locale['admins_blog_settings'] = "Configurações do Blog";
$locale['admins_download_settings'] = "Configurações de Download";
$locale['admins_forum_settings'] = "Definições de Fórum";
$locale['admins_photo_settings'] = "Configurações da Galeria";
$locale['admins_main_settings'] = "Configurações Principais";
$locale['admins_misc_settings'] = "Configurações Diversas";
$locale['admins_news_settings'] = "Configurações de Notícias";
$locale['admins_message_settings'] = "Private Messages Settings";
$locale['admins_register_settings'] = "Registration Settings";
$locale['admins_security_settings'] = "Configurações de Segurança";
$locale['admins_time_settings'] = "Configurações de Data e Hora";
$locale['admins_user_settings'] = "Configurações de Gerenciamento de Usuários";
$locale['admins_theme_settings'] = "Definições de Temas";

// Security Settings
$locale['admins_security_001'] = "Sessões do Sistema";
$locale['admins_security_002'] = "Configuração das sessões do site";
$locale['admins_security_003'] = "Tipo de Sessão";
$locale['admins_security_004'] = "Sistema de Banco de Dados";
$locale['admins_security_005'] = "Sistema de Arquivos";
$locale['admins_security_006'] = "Limpar Cache de Sessões do Sistema";
$locale['admins_security_007'] = "Todas as sessões do sistema foram limpas com sucesso";
$locale['admins_security_008'] = "Tokens de Formulário";
$locale['admins_security_009'] = "Número de tokens emitidos para cada formulário";
$locale['admins_security_010'] = "Fusion GateWay";
$locale['admins_security_011'] = "Método GateWay";
$locale['admins_security_012'] = "Palavras";
$locale['admins_security_013'] = "Números";
$locale['admins_security_014'] = "Ambos";
$locale['admins_security_015'] = "Registro de erros";
$locale['admins_security_016'] = "Método de registro de erros";
$locale['admins_security_017'] = "Arquivo";
$locale['admins_security_018'] = "Database";

include_once __DIR__.'/../../../includes/dateformats.php';
