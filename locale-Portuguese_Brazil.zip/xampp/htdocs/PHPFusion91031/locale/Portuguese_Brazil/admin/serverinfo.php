<?php
$locale['SRV_400'] = "Informações do servidor";
//General
$locale['SRV_401'] = "Geral";
$locale['SRV_402'] = "Software do servidor";
$locale['SRV_403'] = "Software do servidor web";
$locale['SRV_404'] = "Versão do PHP";
$locale['SRV_405'] = "Interface do PHP";
$locale['SRV_406'] = "Versão do servidor MySQL";
$locale['SRV_406a'] = "Driver de banco de dados";
$locale['SRV_407'] = "Versão do PHPFusion";
$locale['SRV_408'] = "Prefixo do banco de dados";
$locale['SRV_409'] = "Prefixo de cookie";
$locale['SRV_410'] = "Navegador web e sistema operacional";
$locale['SRV_411'] = "Traduzido por: Romildo José Dias"; // Se você ajudou com a tradução, pode inserir seu nome aqui. A administração pode atualizar os créditos com base em contribuições recentes.
//PHP settings
$locale['SRV_420'] = "Configurações do PHP";
$locale['SRV_423'] = "Safe-mode";
$locale['SRV_424'] = "RegisterGlobals";
$locale['SRV_425'] = "Suporte para";
$locale['SRV_426'] = "Upload de arquivos (tamanho máximo de arquivo)";
$locale['SRV_428'] = "Exibição de erros";
$locale['SRV_429'] = "Funções desativadas";
$locale['SRV_430'] = "n/a";
$locale['SRV_431'] = "versão";
//Write permission
$locale['SRV_440'] = "Permissões de pasta";
$locale['SRV_441'] = "Gravável";
$locale['SRV_442'] = "Não gravável";
//PHPinfo
$locale['SRV_450'] = "Detalhes";
$locale['SRV_451'] = "Não foi possível obter os dados. Verifique se a função phpinfo() está desativada.";
