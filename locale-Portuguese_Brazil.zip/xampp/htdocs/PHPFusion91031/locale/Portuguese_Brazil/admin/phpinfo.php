<?php
/**
 * Portuguese Brasileiro
 * @tradução Romildo José Dias <rmjdias@hotmail.com>
 */
$locale['400'] = "Informações do PHP";
//Geral
$locale['401'] = "Geral";
$locale['402'] = "Software do servidor";
$locale['403'] = "Software do servidor web";
$locale['404'] = "Versão do PHP";
$locale['405'] = "Interface do PHP";
$locale['406'] = "Versão do servidor MySQL";
$locale['407'] = "Versão do PHP-Fusion";
$locale['408'] = "Prefixo do banco de dados";
$locale['409'] = "Prefixo de cookies";
$locale['410'] = "Navegador Web e sistema operacional";
$locale['411'] = "Traduzido por: Romildo José Dias"; // Se você ajudou com a tradução, pode escrever seu nome aqui. A gestão pode atualizar os créditos com base nas contribuições recentes.
//PHP settings
$locale['420'] = "Configurações do PHP";
$locale['421'] = "Sim";
$locale['422'] = "Não";
$locale['423'] = "Modo seguro (Safe Mode)";
$locale['424'] = "RegisterGlobals";
$locale['425'] = "Suporte para";
$locale['426'] = "Upload de arquivos (tamanho máximo)";
$locale['428'] = "Exibir erros";
$locale['429'] = "Funções desativadas";
$locale['430'] = "n/d";
$locale['431'] = "versão";
//Permissões de escrita
$locale['440'] = "Permissões de pastas";
$locale['441'] = "Com permissão de escrita";
$locale['442'] = "Sem permissão de escrita";
//Informações do PHP (PHPinfo)
$locale['450'] = "Detalhes";
$locale['451'] = "Não foi possível obter os dados. Verifique se a função phpinfo() está desativada.";
