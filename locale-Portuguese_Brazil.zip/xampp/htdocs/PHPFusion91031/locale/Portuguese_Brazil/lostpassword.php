<?php
$locale['400'] = "Esqueceu sua Senha?";
$locale['401'] = "Um e-mail de confirmação foi enviado para o seu endereço.";
$locale['402'] = "A nova senha foi enviada para o seu endereço de e-mail.";
$locale['403'] = "Voltar para o Site Principal";
$locale['404'] = "O endereço de e-mail especificado não foi encontrado.";
$locale['405'] = "O endereço de e-mail que você especificou é inválido.";
$locale['406'] = "Por favor tente novamente.";
$locale['407'] = "Por favor, insira o endereço de e-mail com o qual sua conta está registada abaixo.<br/>Uma nova senha será criada e enviada para este endereço.";
$locale['408'] = "Enviar senha";
$locale['409'] = "Nova senha para ";
$locale['410'] = "Olá [USER_NAME],<br/>
Você ou alguém pediu uma nova palavra--passe para entrar na sua conta do [SITENAME].<br/>
Para alterar a sua senha clique no seguinte link:<br/>[NEW_PASS_LINK]<br/>
Atenciosamente,<br/>[SITEUSERNAME]";
$locale['411'] = "Olá [USER_NAME],<br/>Sua nova senha para aceder à sua conta em [SITENAME] é:<br/>
[NEW_PASS]<br/>Atenciosamente,<br/>[SITEUSERNAME]";
$locale['412'] = "Ocorreu um erro. Tente novamente.";
$locale['413'] = "Insira o seu endereço de e-mail:";
