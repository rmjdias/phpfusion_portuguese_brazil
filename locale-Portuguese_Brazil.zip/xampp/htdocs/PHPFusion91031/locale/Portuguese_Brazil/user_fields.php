<?php
// Items shown in profile
$locale['u040'] = "Data de Entrada";
$locale['u041'] = "Última Visita";
$locale['u042'] = "Não visitado";
$locale['u043'] = "Enviar Mensagem Privada";
$locale['u044'] = "Informações de Contato";
$locale['u045'] = "Informações Diversas";
$locale['u046'] = "Opções";
$locale['u047'] = "Estatísticas";
$locale['u048'] = "Informações do Admin";
$locale['u049'] = "Endereço IP";
$locale['u050'] = "Indefinido";
$locale['u051'] = "Ocultar E-mail?";
$locale['u052'] = " Sim ";
$locale['u053'] = " Não";
$locale['u054'] = "Ver Log de Suspensão";
$locale['u055'] = "Status do usuário:";
$locale['u056'] = "Motivo";
$locale['u057'] = "Grupos de Usuários";
$locale['u058'] = "Opções de Administrador";
$locale['u059'] = "Adicionar";
$locale['u060'] = "Adicionar este usuário ao grupo selecionado?";
$locale['u061'] = "Adicionar ao grupo";
$locale['u062'] = "Avatar do usuário";
$locale['u063'] = "Nível do Usuário";
$locale['u064'] = "E-mail";
$locale['u066'] = "Data de ingresso";
$locale['u067'] = "Última Visita";
$locale['u068'] = "Nome de Usuário";
$locale['u070'] = "Banir";
$locale['u071'] = "Suspender";
$locale['u073'] = "Apagar este usuário?";
$locale['u074'] = "Reativar";
// Profile and register
$locale['u100'] = "Para alterar a sua senha ou endereço de e-mail, você temque inserir a sua senha atual.";
$locale['u101'] = "Registar";
$locale['u102'] = "Editar perfil";
$locale['u103'] = "Perfil";
$locale['u104'] = "Perfil do Usuário";
$locale['u105'] = "Atualizar perfil";

// New UF 1.20
$locale['uf_100'] = "Configurações Gerais da Conta";
$locale['uf_101'] = "Configurações de Informações do Usuário";
$locale['uf_102'] = "Configurações de Avatar de Usuário";
$locale['uf_103'] = "Geral";
$locale['uf_104'] = "Informação do Usuário";
$locale['uf_105'] = "Imagem de perfil";
$locale['uf_106'] = "Informação Básica";
$locale['uf_107'] = "%s não tem nenhuma informação de usuário disponível.";
$locale['uf_108'] = "Não há campos de usuário definidos";

// View User Groups
$locale['u110'] = "Ver Grupo de Usuários";
$locale['u111'] = "%u usuário";
$locale['u112'] = "%u usuários";
$locale['u113'] = "Nome de Usuário";
$locale['u114'] = "Tipo de Usuário";
$locale['u115'] = "Idioma";
$locale['u116'] = "Não há usuários do grupo.";
$locale['u117'] = "Não há grupos de usuários.";
// User name and email
$locale['u119'] = "O nome de usuário contém.";
$locale['u120'] = "O nome de usuário contém caracteres inválidos.";
$locale['u121'] = "O nome de usuário escolhido já está sendo usado por outro usuário.";
$locale['u122'] = "O nome de usuário não pode ser deixado em branco.";
$locale['u123'] = "Endereço de email não parece ser válido.";
$locale['u124'] = "Seu endereço de e-mail ou domínio de e-mail parece estar na lista negra.";
$locale['u125'] = "Este endereço de email já está associado a outra conta.";
$locale['u126'] = "O campo de e-mail não pode ser deixado em branco.";
$locale['u127'] = "Nome de Usuário";
$locale['u128'] = "Endereço de Email";
$locale['u129'] = "Informação Básica";
// Passwords
$locale['u130'] = "Senhas de administrador";
$locale['u131'] = "Senha de administrador";
$locale['u132'] = "Senhas de login";
$locale['u133'] = "Senha de login";
$locale['u134'] = "Nova senha";
$locale['u134a'] = "Definir senha";
$locale['u134b'] = "Repetir senha";
$locale['u135a'] = "Senha atual";
$locale['u135b'] = "Definir nova senha";
$locale['u135c'] = "Repetir nova senha";
$locale['u136'] = "A senha não pode ficar em branco.";
$locale['u137'] = "A sua senha de administrador atual não pode ser deixada em branco.";
$locale['u138'] = "A sua senha de usuário atual não pode ser deixada em branco.";
$locale['u139'] = "A senha de usuário não coincide com sua senha de usuário atual.";
$locale['u140'] = "A senha de Administador não corresponde à sua Senha de Administrador atual.";
$locale['u141'] = " não pode ser o mesmo que ";
$locale['u142'] = " é curto demais ou contém caracteres inválidos!";
$locale['u143'] = " não coincide!";
$locale['u143a'] = " não pode ser deixado em branco.";
$locale['u144'] = "Nova senha de admin";
$locale['u144a'] = "Senha de admin atual";
$locale['u145'] = "Confirme a senha de admin";
$locale['u146'] = " não pode ser o mesmo que a sua atual ";
$locale['u147'] = "A Senha tem que ter entre 8 e 64 caracteres.<br/>Símbolos permitidos são a-z, 0-9 e @!#$%&/()=-_?+*.,:;";
$locale['u148'] = "As novas Senhas de usuário não são idênticas.";
$locale['u148a'] = "As novas Senhas de Administrador não são idênticas.";
$locale['u149'] = "A sua Senha de usuário Actual não foi especificada ou é inválida.";
$locale['u149a'] = "A sua Senha de Admnistrador Actual não foi especificada ou é inválida.";
$locale['u149b'] = "A sua Senha de Usuário Actual não foi especificada ou é inválida.<br/>Não pode defenir a sua senha de administrador sem a senha de usuário correta.";
// Email activation
$locale['u150'] = "O seu registo está quase completo. Irá receber um e-mail contendo os seus dados de login juntamente com um link para verificar a sua conta.";
$locale['u151'] = "Bem-vindo ao [SITENAME]";
$locale['u152'] = "Olá USER_NAME,<br/>

Bem-vindo ao SITENAME. Aqui estão os seus detalhes de login:<br/>

Nome de usuário: USER_NAME<br/>

Senha: USER_PASSWORD<br/>

Por favor, ative sua conta através do seguinte link: ACTIVATION_LINK<br/>

Atenciosamente,<br/>

SITEUSERNOME";

$locale['u153'] = "O e-mail de ativação não pode ser enviado.";
$locale['u154'] = "Por favor [LINK]entre em contacto com[/LINK] o administrador do site.";
$locale['u155'] = "Ativar Conta";
$locale['u156'] = "Por favor, insira a senha atual para alterar o e-mail.";
// Success / Fail
$locale['u160'] = "Registo completo";
$locale['u161'] = "Agora você pode entrar.";
$locale['u162'] = "Um administrador ativará a sua conta em breve.";
$locale['u163'] = "O perfil foi atualizado com sucesso.";
$locale['u164'] = "A atualização falhou";
$locale['u165'] = "O e-mail foi re-enviado.";

$locale['u167'] = "pelo(s) seguinte(s) motivo(s):";
$locale['u168'] = "Por favor, tente novamente.";
$locale['u169'] = "Perfil atualizado";
$locale['u170'] = "Registo efetuado com sucesso";
$locale['u171'] = "A sua conta foi verificada.";
$locale['u172'] = "Usuário adicionado com sucesso.";
$locale['u173'] = "Voltar para a Gestão de Usuários.";
$locale['u174'] = "Adicionar outro usuário.";
// Avatar upload
$locale['u180'] = "Ocorreu um erro ao carregar a imagem do perfil";

$locale['u184'] = "Tamanho máx. do arquivo: %s / tamanho máximo: %ux%u pixels";
$locale['u185'] = "Imagem de Perfil";
$locale['u186'] = "Clique em Procurar para enviar uma imagem";
// Captcha and terms
$locale['u190'] = "Código de Validação";
$locale['u191'] = "Insira o código de validação";
$locale['u192'] = "Termos & Condições";
$locale['u193'] = "Eu li os [LINK]Termos e Condições[/LINK] e concordo com eles.";
$locale['u193a'] = "Atualizado";
$locale['u193b'] = "Concordo";
$locale['u194'] = "Código de verificação incorrecto.";
$locale['u195'] = "O código captcha não pode ser deixado em branco.";
// E-mail Change Confirmation
$locale['u200'] = "Um e-mail de verificação foi enviado para o seu novo endereço de e-mail (%s). Por favor, verifique seu e-mail.";
$locale['u201'] = "O seu endereço de e-mail irá ser alterado quando clicar no link no e-mail.";
$locale['u202'] = "Verificação de endereço de e-mail - [SITENAME]";
$locale['u203'] = "Olá [USER_NAME],<br/>

Alguém definiu este endereço de e-mail em sua conta no nosso site.<br/>

Se você realmente quer mudar seu endereço de e-mail para este, por favor clique no seguinte link:<br/>

[EMAIL_VERIFY_LINK]<br/>

Nota: você precisa ter a sessão iniciada para prosseguir.<br/>

Atenciosamente,
[SITEUSERNAME]<br/>

[SITENAME]";
// Checker
$locale['u300'] = "A senha deve conter pelo menos 1 caractere especial";
$locale['u301'] = "A senha deve conter pelo menos 1 caractere maiúsculo e 1 caractere minúsculo.";
$locale['u302'] = "A senha deve conter pelo menos 1 número";
$locale['u303'] = "A senha deve ter pelo menos 8 caracteres";
