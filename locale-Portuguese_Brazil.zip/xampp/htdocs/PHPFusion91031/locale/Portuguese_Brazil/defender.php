<?php
$locale['validate'] = "Por favor, verifique e revalide o campo.";
$locale['error_request'] = "Ocorreu um erro ao processar sua solicitação.";
$locale['regex_error'] = "Por favor, verifique e revalide o campo %s";
// Text fields errors
$locale['error_input_username'] = "Por favor, introduz um nome de usuário válido";
$locale['error_input_default'] = "Por favor, preencha este campo";
$locale['error_input_password'] = "Por favor, insira uma senha válida";
$locale['error_input_email'] = "Por favor insira um email válido";
$locale['error_input_number'] = "Por favor, insira um número válido";
$locale['error_input_url'] = "Por favor, insira uma URL válida";
$locale['error_input_regex'] = "Por favor insira uma data válida";
$locale['error_input_safemode'] = "Por favor, preencha este campo correctamente";
$locale['error_input_check'] = "Por favor, preencha um valor correto de campo";
$locale['df_error_text'] = "%s tem um erro e requer sua atenção.";
$locale['error_invalid_theme'] = "Por favor, selecione um tema válido";
$locale['error_input_checkbox'] = "Por favor, assinala esta caixa";
$locale['error_input_file'] = "Por favor, selecione um tema válido";
$locale['error_secure_file'] = "O arquivo enviado foi rejeitado devido à possibilidade de conter uma carga maliciosa.";
$locale['error_input_login'] = "Nome de usuário ou senha incorreta";
// Admin Login
$locale['cookie_title'] = "A sessão expirou";
$locale['cookie_description'] = "Não há autenticação válida / ou a sua sessão provavelmente expirou. Por favor, faça login novamente.";
$locale['cookie_expired'] = "A sua sessão expirou. Por favor, inicie sessão novamente.";
$locale['password_invalid'] = "Senha errada ou inválida";
$locale['password_invalid_description'] = "A senha digitada está incorreta. Tente novamente.";
$locale['prefix_error'] = "O país requer atenção.";
$locale['contact_error'] = "O número de contato requer atenção.";
$locale['cookie_error'] = "Erro de Cookie";
$locale['cookie_error_description'] = "Você precisa ativar os cookies no navegador para entrar na administração.";
$locale['validate_title'] = "Você poderia verificar algo?";
// Address errors
$locale['street_error'] = "O endereço da rua requer atenção.";
$locale['country_error'] = "O país requer atenção.";
$locale['state_error'] = "O Estado precisa de atenção.";
$locale['city_error'] = "A cidade precisa de atenção.";
$locale['postcode_error'] = "O código postal precisa de atenção.";
$locale['field_error_blank'] = "%s não pode estar vazio.";
// Name errors
$locale['firstname_error'] = "O primeiro nome precisa de atenção.";
$locale['lastname_error'] = "O sobrenome precisa de atenção.";
$locale['name_error'] = "O nome e o sobrenome não podem ser os mesmos.";
// Document errors
$locale['doc_type_error'] = "Tipo de documento requer atenção.";
$locale['doc_series_error'] = "A série de documentos requer atenção.";
$locale['doc_number_error'] = "O número do documento requer atenção.";
$locale['doc_authority_error'] = "A autoridade responsável pelos documentos requer atenção.";
$locale['date_issue_error'] = "Data de emissão do documento requer atenção.";
// Tokens
$locale['token_error_title'] = "Erro de Token";
$locale['token_error'] = "Desculpe, ocorreu um erro. Por favor, volte atrás, atualize a página e tente novamente.";
$locale['token_error_1'] = "Sessão não iniciada.";
$locale['token_error_2'] = "O token não foi publicado.";
$locale['token_error_3'] = "Token inválido. ";
$locale['token_error_4'] = "Id de usuário inválido dentro do token.";
$locale['token_error_5'] = "Selo de Token inválido";
$locale['token_error_6'] = "O post foi feito muito rapidamente.";
$locale['token_error_7'] = "Token inválido.";
$locale['token_error_8'] = "Formato do token inválido.";
$locale['token_error_9'] = "Não foi possível encontrar nenhum token para este formulário.";
$locale['token_error_10'] = "Não foi possível encontrar nenhum token para o armazenamento: ";

$locale['df_300'] = "Clique para adicionar arquivos";
$locale['df_301'] = "Clique para adicionar fotos";
$locale['df_302'] = "Clique para adicionar vídeos";
$locale['df_303'] = "Clique para adicionar áudio";
$locale['df_304'] = "Remover arquivo selecionado";

$locale['df_400'] = "%s contém caracteres inválidos.";
$locale['df_401'] = "%s não é um endereço de e-mail válido.";
$locale['df_402'] = "%s não é uma senha válida.";
$locale['df_403'] = "%s não é um número válido.";
$locale['df_404'] = "%s não é uma data válida.";
$locale['df_405'] = "%s não é uma URL válida.";
$locale["df_406"] = "%s possui um tipo definido que é desconhecido.";
$locale['df_415'] = "Nome de arquivo inválido.";
$locale['df_416'] = "Arquivo muito grande. O arquivo deve ser menor que %s.";
$locale['df_417'] = "O arquivo enviado não é um tipo de arquivo válido. O arquivo deve ser um dos seguintes tipos de arquivo - %s";
$locale['df_418'] = "O Arquivo de upload está bom, mas a extensão é inválida. Por favor, renomeie a extensão do arquivo e tente novamente.";
$locale['df_419'] = "Falha na verificação da imagem. Por favor, recrie a sua imagem.";
$locale['df_420'] = "A pasta não existe. Por favor, crie a pasta via FTP e tente novamente.";
$locale['df_421'] = "A imagem não pode ser maior que %uw x %uh píxeis.";
$locale['df_422'] = "Erro desconhecido (Consulta)";
$locale['df_423'] = "Arquivo(s) não submetidos. Por favor, tente novamente";
$locale['df_424'] = "A quantidade de arquivos que você está tentando enviar excede o limite máximo. Tente novamente e anexe menos arquivos.";

$locale['error_rate'] = "Por favor insira uma avaliação.";
$locale['error_type'] = "Por favor, insira o Tipo de Extensão.";
$locale['error_width'] = "Por favor, insira a largura.";
$locale['error_height'] = "Por favor, insira a Altura.";
$locale['error_value'] = "Por favor, insira um valor.";

// ReCaptcha
$locale['grecaptcha'] = "Google Recaptcha";
$locale['grecaptcha3'] = "Google Recaptcha v3";
$locale['grecaptcha_desc'] = "Módulo de Campo do Google Recaptcha";
$locale['grecaptcha_placeholder_1'] = "Chave do site (SITE KEY) do Google";
$locale['grecaptcha_placeholder_2'] = "Chave secreta (SECRET KEY) do Google";
$locale['no_keys'] = "Parece que você ainda não possui nenhuma chave. Cadastre-se e obtenha sua [RECAPTCHA_LINK]chave pública aqui[/RECAPTCHA_LINK]";
$locale['grecaptcha_0100'] = "Chave do Site";
$locale['grecaptcha_0101'] = "Chave secreta";
$locale['grecaptcha_0102'] = "Tema";
$locale['grecaptcha_0102a'] = "Claro";
$locale['grecaptcha_0102b'] = "Escuro";
$locale['grecaptcha_0103'] = "Tipo de Validação";
$locale['grecaptcha_0103a'] = "Texto";
$locale['grecaptcha_0103b'] = "Áudio";
$locale['grecaptcha_0104'] = "Pontos";
$locale['grecaptcha_warn'] = "Por favor, insira a sua chave reCAPTCHA pública e privada";
