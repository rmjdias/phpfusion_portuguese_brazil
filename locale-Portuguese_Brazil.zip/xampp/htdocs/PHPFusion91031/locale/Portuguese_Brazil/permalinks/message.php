<?php
$locale['pl_message_title'] = "Mensagens";
$locale['pl_message_desc'] = "Ativa links permanentes (permalinks) para o sistema de mensagens privadas.";
