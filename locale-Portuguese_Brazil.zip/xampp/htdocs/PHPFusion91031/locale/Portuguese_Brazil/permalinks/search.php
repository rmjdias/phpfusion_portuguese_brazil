<?php
$locale['pl_search_title'] = "Busca";
$locale['pl_search_desc'] = "Ativa links permanentes (permalinks) para o mecanismo de busca no site.";
