<?php
$locale['pl_profiles_title'] = "Perfil de usuário";
$locale['pl_profiles_desc'] = "Ativa links permanentes (permalinks) para as páginas de perfil dos usuários.";
