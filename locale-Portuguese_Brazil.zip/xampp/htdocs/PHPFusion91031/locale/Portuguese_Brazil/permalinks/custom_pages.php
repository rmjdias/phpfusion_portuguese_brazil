<?php
$locale['pl_cp_title'] = "Páginas Personalizadas";
$locale['pl_cp_desc'] = "Ativar links permanentes (permalinks) para as Páginas Personalizadas.";
