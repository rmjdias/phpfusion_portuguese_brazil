<?php
$locale['pl_homepage_title'] = "Página inicial";
$locale['pl_homepage_desc'] = "Ativa links permanentes (permalinks) para a página inicial do site.";
