<?php
$locale['r100'] = "Avaliação";
$locale['r101'] = "Não foram publicadas avaliações.";
$locale['r102'] = "Remover classificação";
$locale['r103'] = "Classificação";
$locale['r104'] = "A avaliação está disponível apenas para usuários.<br/>Por favor, [RATING_ACTION] para votar.";
$locale['r105'] = "Você avaliou isto como %s em %s";
$locale['r106'] = "Por favor, selecione sua Avaliação";
$locale['r107'] = "Escolha a Avaliação:";
$locale['r108'] = "Sem Votos";
$locale['r109'] = "Voto";
$locale['r110'] = "Votos";
// Rating Options
$locale['r120'] = "Incrível!";
$locale['r121'] = "Muito bom";
$locale['r122'] = "Bom";
$locale['r123'] = "Médio";
$locale['r124'] = "Ruim";
