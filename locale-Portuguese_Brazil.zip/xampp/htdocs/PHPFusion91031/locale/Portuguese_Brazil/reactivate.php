<?php
// Error messages
$locale['500'] = "Ocorreu um erro";
$locale['501'] = "O link de reativação que você clicou é inválido.<br /><br />Entre em contacto com o administrador do site em [SITEEMAIL] se você deseja solicitar uma reativação manual.";
$locale['502'] = "O link de reativação que você clicou é inválido.<br /><br />Entre em contacto com o administrador do site em [SITEEMAIL] se você deseja solicitar uma reativação manual.";
$locale['503'] = "O link de reativação que você seguiu não pôde reativar sua conta.<br />
Talvez a sua conta já tenha sido reativada e, nesse caso, você deve ser capaz de [LINK]fazer login aqui[/LINK].<br /><br />
Se não puder entrar agora, por favor contacte o administrador do site em [SITEEMAIL] se você deseja solicitar uma reativação manual.";
// Send confirmation mail
$locale['504'] = "Conta reativada em [SITENAME]";
$locale['505'] = "Olá [USER_NAME],
<br/>
A sua conta em [SITENAME] foi reativada. Esperamos vê-lo mais frequentemente no site.<br/><br/>

Atenciosamente,<br/><br/>
[SITEUSERNAME]";
$locale['506'] = "Reativada pelo usuário.";
