<?php
$locale['setlocale'] = "pt_BR"; // https://www.php.net/manual/en/function.setlocale.php
$locale['charset'] = "utf-8"; // https://www.iana.org/assignments/character-sets/character-sets.xhtml
$locale['region'] = "BR"; // ISO-3166 (Alpha-2 code) https://www.iso.org/obp/ui/#search
$locale['xml_lang'] = "en"; // ISO 639-1 Code http://www.loc.gov/standards/iso639-2/php/code_list.php
$locale['short_lang_name'] = "br"; // ISO 639-1 Code http://www.loc.gov/standards/iso639-2/php/code_list.php
$locale['tinymce'] = "br"; // refer to path locale/Lang/includes/jscripts/tinymce/langs/{value}.js
$locale['select2'] = "pt-BR"; // refer to path locale/Lang/includes/dynamics/assets/select2/select2_locale_{value}.js
$locale['phpmailer'] = "br"; // refer to path locale/Lang/includes/classes/PHPMailer/language/phpmailer.lang-{value}.php
$locale['filemanager'] = "br"; // refer to path locale/Lang/includes/elFinder/js/i18n/{value}.js
$locale['datepicker'] = "pt-br"; // refer to path locale/Lang/includes/dynamics/assets/datepicker/locale/{value}.js
$locale['password_strength'] = "br"; // refer to path locale/Lang/includes/dynamics/assets/password/lang/{value}.js
$locale['text-direction'] = "ltr";
// Full & Short Months
$locale['months'] = "&nbsp;| Janeiro|Fevereiro|Março|Abril|Maio|Junho|Julho|Agosto|Setembro|Outubro|Novembro|Dezembro";
$locale['shortmonths'] = "&nbsp;|Jan|Fev|Mar|Abr|Maio|Jun|Jul|Ago|Set|Out|Nov|Dez";
$locale['weekdays'] = "Domingo|Segunda|Terça|Quarta|Quinta|Sexta|Sábado";
// Timers
$locale['year'] = "ano";
$locale['year_a'] = "anos";
$locale['month'] = "mês";
$locale['month_a'] = "meses";
$locale['week'] = "semana";
$locale['week_a'] = "semanas";
$locale['day'] = "dia";
$locale['day_a'] = "dias";
$locale['hour'] = "hora";
$locale['hour_a'] = "horas";
$locale['minute'] = "minuto";
$locale['minute_a'] = "minutos";
$locale['second'] = "segundo";
$locale['second_a'] = "segundos";
$locale['just_now'] = "agora mesmo";
$locale['now'] = 'agora';
$locale['ago'] = "atrás";
// Geo
$locale['street1'] = "Endereço (Linha 1)";
$locale['street2'] = "Endereço (Linha 2)";
$locale['city'] = "Cidade";
$locale['postcode'] = "Código postal";
$locale['sel_country'] = "Selecionar País";
$locale['sel_state'] = "Selecionar região";
$locale['sel_user'] = "Insira um nome de usuário!";
$locale['add_language'] = "Adicionar Traduções de Idioma";
$locale['add_lang'] = "Adicionar %s";
$locale['other_states'] = "Outros Estados";
// Name
$locale['name'] = "Nome Completo";
$locale['username_pretext'] = "Seu nome de usuário público também é o mesmo que seu endereço de perfil de usuário localizado em: %s %s";
$locale['first_name'] = "Primeiro nome";
$locale['middle_name'] = "Nome do Meio";
$locale['last_name'] = "Sobrenome";
// Documents
$locale['doc_type'] = "Tipo de documento";
$locale['doc_series'] = "Série";
$locale['doc_number'] = "Número";
$locale['doc_authority'] = "Autoridade";
$locale['doc_date_issue'] = "Data de emissão";
$locale['doc_date_expire'] = "Data de validade";
// Standard User Levels
$locale['user0'] = "Público";
$locale['user1'] = "Usuário";
$locale['user2'] = "Administrador";
$locale['user3'] = "Super Administrador";
$locale['user_na'] = "N/A";
$locale['user_guest'] = "Visitante";
$locale['user_anonymous'] = "Usuário Anônimo";
$locale['genitive'] = "%sde %s";
// Standard User Status
$locale['status0'] = "Ativo";
$locale['status1'] = "Banido";
$locale['status2'] = "Desativado";
$locale['status3'] = "Suspenso";
$locale['status4'] = "Banido por Segurança";
$locale['status5'] = "Cancelado";
$locale['status6'] = "Anônimo";
$locale['status7'] = "Desativado";
$locale['status8'] = "Inativo";
// Forum Moderator Level(s)
$locale['userf1'] = "Moderador";
// Navigation
$locale['global_001'] = "Navegação";
$locale['global_002'] = "Nenhum link definido";
$locale['global_003'] = "Nada para pré-visualizar";
// Users Online
$locale['global_010'] = "Usuários Online Agora";
$locale['global_011'] = "Visitantes online";
$locale['global_012'] = "Usuários Online";
$locale['global_013'] = "Nenhum Usuário Online";
$locale['global_014'] = "Total de Usuários";
$locale['global_015'] = "Usuários inativos";
$locale['global_016'] = "Usuário mais recente";
$locale['global_017'] = "Ativar/Desativar Navegação";
// Forum Side panel
$locale['global_020'] = "Tópicos do Fórum";
$locale['global_021'] = "Últimas Discussões";
$locale['global_022'] = "Tópicos mais populares";
$locale['global_023'] = "Nenhum tópico criado";
$locale['global_024'] = "Discussões em que participou";
$locale['global_027'] = "Tópicos por responder";
$locale['global_028'] = "Perguntas sem resposta";
// Comments Side panel
$locale['global_025'] = "Últimos comentários";
$locale['global_026'] = "Não há comentários disponíveis";
// Articles Side panel
$locale['global_030'] = "Artigos mais Recentes";
$locale['global_031'] = "Não há artigos disponíveis";
// Downloads Side panel
$locale['global_032'] = "Últimos Downloads";
$locale['global_033'] = "Não há downloads disponíveis";
// Welcome_panel
$locale['global_035'] = "Bem-vindo";
// Latest Active Forum Threads panel
$locale['global_040'] = "Últimos tópicos ativos do fórum";
$locale['global_041'] = "Os meus tópicos recentes";
$locale['global_042'] = "Os meus posts recentes";
$locale['global_043'] = "Novos posts";
$locale['global_044'] = "Tópico";
$locale['global_045'] = "Visualizações";
$locale['global_046'] = "Respostas";
$locale['global_047'] = "Último post";
$locale['global_048'] = "Fórum";
$locale['global_049'] = "Submetido";
$locale['global_050'] = "Autor";
$locale['global_051'] = "Votação";
$locale['global_052'] = "Movido";
$locale['global_053'] = "Você ainda não iniciou nenhum tópico do fórum.";
$locale['global_054'] = "Você ainda não publicou nenhuma mensagem no fórum.";
$locale['global_055'] = "Há %u novas postagens em %u tópicos diferentes desde a sua última visita.";
$locale['global_056'] = "Acompanhar tópico";
$locale['global_057'] = "Opções";
$locale['global_058'] = "Parar seguimento";
$locale['global_059'] = "Você não está acompanhando nenhum tópico.";
$locale['global_060'] = "Deixar de acompanhar este tópico?";
// Blog, News & Articles
$locale['global_070'] = "Publicado por ";
$locale['global_070b'] = "Ver todos os posts de %s";
$locale['global_071'] = "em ";
$locale['global_071b'] = "Autor";
$locale['global_072'] = "Continuar a ler";
$locale['global_073'] = " Comentários";
$locale['global_073b'] = " Comentário";
$locale['global_074'] = " Leituras";
$locale['global_074b'] = " Lido";
$locale['global_075'] = "Imprimir";
$locale['print'] = "Imprimir";
$locale['global_076'] = "Editar";
$locale['global_077'] = "Notícias";
$locale['global_078'] = "Nenhuma notícia foi publicada ainda";
$locale['global_079'] = "Em ";
$locale['global_080'] = "Sem Categoria";
$locale['global_081'] = "Notícias";
$locale['global_082'] = "Notícias";
$locale['global_083'] = "Última Atualização";
$locale['global_084'] = "Categoria de Notícias";
$locale['global_085'] = "Todas as outras Categorias";
$locale['global_086'] = "Notícias Mais Recentes";
$locale['global_087'] = "Notícias Mais Comentadas";
$locale['global_088'] = "Notícias de Maior Avaliação";
$locale['global_089'] = "Seja o primeiro a comentar sobre %s";
$locale['global_089a'] = "Seja o primeiro a avaliar este %s";
$locale['global_089b'] = "Visualização em miniaturas";
$locale['global_089c'] = "Visualização em lista";
// Page Navigation
$locale['global_090'] = "Anterior";
$locale['global_091'] = "Próximo";
$locale['global_092'] = "Página ";
$locale['global_093'] = " de ";
$locale['global_094'] = " de um máximo de ";
// Guest User Menu
$locale['global_100'] = "Iniciar Sessão";
$locale['global_101'] = "ID de usuário";
$locale['global_101a'] = "Insira o seu nome de usuário";
$locale['global_101b'] = "Insira Email";
$locale['global_101c'] = "Insira o E-mail ou Nome de Usuário";
$locale['global_102'] = "Palavra-chave";
$locale['global_103'] = "Manter sessão iniciada";
$locale['global_104'] = "Iniciar Sessão";
$locale['global_105'] = "Ainda não é um usuário? [LINK]Clique aqui[/LINK] para se registar.";
$locale['global_106'] = "[LINK]Esqueceu a sua senha?[/LINK]";
$locale['global_107'] = "Registar";
$locale['global_108'] = "Esqueceu-se da senha";
$locale['global_109'] = "Registar";
// Member User Menu
$locale['global_120'] = "Personalize a sua página de perfil";
$locale['global_121'] = "Mensagens Privadas";
$locale['global_122'] = "Lista de Usuários";
$locale['global_123'] = "Painel de Administração";
$locale['global_124'] = "Encerrar Sessão";
$locale['global_125'] = "Você tem %u novas ";
$locale['global_126'] = "mensagem";
$locale['global_127'] = "mensagens";
$locale['global_128'] = "submissão";
$locale['global_129'] = "submissões";
$locale["global_130"] = "O painel %s não pôde ser encontrado";
// User Menu
$locale['UM060'] = "Iniciar sessão";
$locale['UM061'] = "Nome do Usuário";
$locale['UM061a'] = "E-mail";
$locale['UM061b'] = "Nome de usuário ou E-mail";
$locale['UM062'] = "Senha";
$locale['UM063'] = "Lembrar-me neste computador";
$locale['UM064'] = "Iniciar sessão";
$locale['UM065'] = "Ainda não é um usuário? [LINK]Clique aqui[/LINK] para se registar.";
$locale['UM066'] = "Esqueceu a sua senha?<br/>[LINK]Solicite uma nova[/LINK].";
$locale['UM067'] = "(não recomendado em um computador público ou compartilhado)";
$locale['UM080'] = "Editar perfil";
$locale['UM081'] = "Mensagens Privadas";
$locale['UM082'] = "Lista de Usuários";
$locale['UM083'] = "Painel de Administração";
$locale['UM084'] = "Encerrar Sessão";
$locale['UM085'] = "Você tem %u novas ";
$locale['UM086'] = "mensagem";
$locale['UM087'] = "mensagens";
$locale['UM088'] = "Tópicos seguidos";
// Submit (news, link, article)
$locale['UM089'] = "Enviar...";
$locale['UM090'] = "Enviar notícias";
$locale['UM091'] = "Enviar Link";
$locale['UM092'] = "Enviar Artigo";
$locale['UM093'] = "Enviar foto";
$locale['UM094'] = "Enviar Download";
$locale['UM095'] = "Enviar blog";
$locale['UM102'] = "Enviar FAQ";
// User Panel
$locale['UM096'] = "Bem-vindo: ";
$locale['UM097'] = "Menu pessoal";
$locale['UM101'] = "Alterar idioma";
$locale['UM103'] = "Logoff como usuário";
// Gauges
$locale['UM098'] = "Caixa de entrada PM:";
$locale['UM099'] = "Caixa de saída PM:";
$locale['UM100'] = "Arquivo PM:";
// Keywords and Meta
$locale['tags'] = "Etiquetas";
// Captcha
$locale['global_150'] = "Código de Validação:";
$locale['global_151'] = "Insira o Código de Validação:";
// Footer Counter
$locale['global_170'] = "visita única";
$locale['global_171'] = "visitas únicas";
$locale['global_172'] = "Tempo de renderização: %s segundos";
$locale['global_173'] = "Consultas";
$locale['global_174'] = "Memória usada";
$locale['global_175'] = "Média: %s segundos";
$locale['global_176'] = "Política de Privacidade";
// Admin Navigation
$locale['global_180'] = "Início da Administração";
$locale['global_181'] = "Voltar ao Site";
$locale['global_182'] = "Senha de administrador não inserida ou incorreta.";
$locale['global_183'] = "Sua sessão de login expirou. Por favor faça login novamente.";
$locale['global_184'] = "Você está logado como %s";
$locale['global_185'] = "Você retornou à sua própria conta.";
// Miscellaneous
$locale['global_190'] = "Modo de manutenção ativo";
$locale['global_191'] = "O seu endereço IP está atualmente na lista negra.";
$locale['global_192'] = "A sua sessão expirou. Por favor, inicie sessão novamente.";
$locale['global_193'] = "Não foi possível definir o cookie do documento. Por favor, certifique-se de que os cookies estão ativados para poder fazer o login correctamente.";
$locale['global_194'] = "Esta conta foi suspensa.";
$locale['global_195'] = "A sua conta ainda não foi ativada.";
$locale['global_196'] = "Nome de usuário ou senha inválidos.";
$locale['global_197'] = "Por favor, aguarde enquanto carregamos a página...<br/>[ [LINK]Ou clique aqui se você não quiser esperar[/LINK]]";
$locale['global_198'] = "ATENÇÃO: INSTALLER DETECTADO, POR FAVOR APAGAR O ARQUIVO INSTALL.PHP IMEDIATAMENTE.";
$locale['global_199'] = "AVISO: senha do administrador não definida, clique em [LINK]Editar perfil[/LINK] para defini-la.";
// Titles
$locale['global_200'] = " - ";
$locale['global_201'] = ": ";
$locale['global_202'] = "Pesquisar";
$locale['global_203'] = "FAQ";
$locale['global_204'] = "Fórum";
// Themes
$locale['global_210'] = "Ir para o Conteúdo";
$locale['global_300'] = "nenhum tema encontrado";
$locale['global_301'] = "Lamentamos muito, mas esta página não pode ser exibida. Devido a algumas circunstâncias nenhum tema do site foi encontrado.
 Se você é um Administrador do Site, por favor, use seu cliente FTP para fazer o upload de qualquer tema projectado para o PHPFusion 9 para o directório de temas.
 Após fazer upload, verifique nas configurações de tema para ver se o tema seleccionado foi enviado corretamente para o diretório de temas.
 Por favor, note que o directório do tema enviado deve ter exatamente o mesmo nome (incluindo maíusculas e minúsculas, que é importante em servidores baseados em Unix)
 como escolhido na página de Configurações do Tema.<br/>Se você é um usuário regular deste site, por favor, entre em contacto com o administrador do site através de [SITE_EMAIL] e-mail e reporte este problema.";
$locale['global_302'] = "O tema escolhido nas Configurações Principais não existe ou está incompleto!";
// JavaScript Not Enabled
$locale['global_303'] = "Oh não! Onde está o JavaScript?<br/>O seu navegador da Web não tem JavaScript ativado ou não suporta JavaScript.
Por favor, ative o JavaScript no seu navegador para ver correctamente este site, ou atualize para um navegador da Web que suporte JavaScript.";
// User Management
$locale['global_400'] = "suspenso";
$locale['global_401'] = "banido";
$locale['global_402'] = "desativada";
$locale['global_403'] = "conta encerrada";
$locale['global_404'] = "conta anonimizada";
$locale['global_405'] = "usuário Anônimo";
$locale['global_406'] = "Esta conta foi banida pela seguinte razão:";
$locale['global_407'] = "Esta conta foi suspensa até ";
$locale['global_408'] = " pelo seguinte motivo:";
$locale['global_409'] = "Esta conta foi banida por motivos de segurança.";
$locale['global_410'] = "A razão é a seguinte: ";
$locale['global_411'] = "Esta conta foi cancelada.";
$locale['global_412'] = "Esta conta foi anonimizada, provavelmente por inactividade.";
// Flood control
$locale['global_440'] = "Banido Automático pelo Controlo Anti-Flood";
$locale['global_441'] = "A sua conta em [SITENAME] foi banida";
$locale['global_442'] = "Olá [USER_NAME],<br/>
A sua conta em [SITENAME] foi apanhada publicando muitos itens no sistema em muito pouco tempo a partir do IP [USER_IP], e foi banida! Isto é feito para evitar que os bots enviem mensagens de spam rapida e sucessivamente.<br/>
Entre em contacto com o administrador do site em [SITE_EMAIL] para que a sua conta seja restaurada ou reporte se não foi você que causou essa falha de segurança.<br/>
Atenciosamente,<br/>[SITEUSERNAME]";
// Authenticate Class
$locale['global_450'] = "Suspensão automaticamente levantada pelo sistema";
$locale['global_451'] = "Suspensão levantada às [SITENAME]";
$locale['global_452'] = "Olá USER_NAME,<br/>
A suspensão da sua conta em [SITEURL] foi levantada. Aqui estão os seus detalhes de login:<br/>
Nome de usuário: USER_NAME<br/>Senha: Oculto por razões de segurança<br/>
Se você esqueceu sua Senha, você pode restaurá-la através do seguinte link: LOST_PASSWORD<br/>
Atenciosamente,<br/>[SITEUSERNAME]";
$locale['global_453'] = "Olá USER_NAME,<br/>A suspensão da sua conta em [SITEURL] foi levantada.<br/>
Atenciosamente,<br/>[SITEUSERNAME]";
$locale['global_454'] = "Conta reativada em [SITENAME]";
$locale['global_455'] = "Olá USER_NAME,<br/>
Na última vez que você entrou na sua conta em [SITEURL], a mesma foi reativada e não está mais marcada como inativa.<br/>
Atenciosamente,<br/>[SITEUSERNAME]";
$locale['global_456'] = "Nova notificação da senha para [SITENAME]";
$locale['global_457'] = "Oi USER_NAME,
<br/>Uma nova senha foi definida para a sua conta em [SITENAME]. Por favor, encontre os novos detalhes de login:<br/>
Nome de Usuário: USER_NAME<br/>Senha: [PASSWORD]<br/>Atenciosamente,<br/>[SITEUSERNAME]";
$locale['global_458'] = "Nova senha foi definida para USER_NAME";
$locale['global_459'] = "Nova senha foi definida para USER_NAME, e o e-mail não foi enviado. Por favor, certifique-se de informar o usuário dos novos detalhes.";
// Function parsebytesize()
$locale['global_460'] = "Vazio";
$locale['global_461'] = "Bytes";
// Safe Redirect
$locale['global_500'] = "Você está sendo redireccionado para %s, por favor aguarde. Se você não foi redireccionado, clique aqui.";
// Captcha Locales
$locale['global_600'] = "Código de Validação";
$locale['global_601'] = "Tem que indicar o código de validação correcto";
$locale['recaptcha'] = "pt";
// Site links
$locale['global_700'] = "Mostrar Mais";
// Miscellaneous
$locale['global_900'] = "Não é possível converter HEX para DEC";
$locale['global_901'] = "Inserir Média";
// Language Selection
$locale['global_ML100'] = "Idioma:";
$locale['global_ML101'] = "-- Seleccione o Idioma --";
$locale['global_ML102'] = "Idioma do Site";
$locale['global_ML103'] = "Alterar idioma";
// Flood Control
$locale['flood'] = "Você está bloqueado de postar até que o tempo de espera tenha terminado. Por favor, aguarde %s.";
$locale['no_image'] = "Nenhuma Imagem";
$locale['send_message'] = "Enviar Mensagem";
$locale['go_profile'] = "Ir para a página de perfil de %s";
// Global one word locales
$locale['hello'] = "Olá!";
$locale['goodbye'] = "Adeus!";
$locale['welcome'] = "Bem-vindo de volta";
$locale['home'] = "Início";
// Status
$locale['error'] = "Erro!";
$locale['success'] = "Sucesso!";
$locale['enable'] = "Ativar";
$locale['disable'] = "Desativar";
$locale['can'] = "pode";
$locale['cannot'] = "não pode";
$locale['no'] = "Não";
$locale['yes'] = "Sim";
$locale['off'] = "Desligado";
$locale['on'] = "Ligado";
$locale['or'] = "ou";
$locale['by'] = "por";
$locale['in'] = "em";
$locale['of'] = "de";
$locale['and'] = "e";
$locale['na'] = "Nenhuma informação disponível";
$locale['joined'] = "Registou-se desde: ";
// Navigation
$locale['next'] = "Próximo";
$locale['previous'] = "Anterior";
$locale['back'] = "Regressar";
$locale['first'] = "Primeira";
$locale['last'] = "Última";
$locale['forward'] = "Avançar";
$locale['go'] = "Ir";
$locale['cancel'] = "Cancelar";
$locale['clear'] = "Limpar";
$locale['move'] = "Mover";
$locale['move_up'] = "Mover para cima";
$locale['move_down'] = "Mover para baixo";
$locale['load_more'] = "Carregar Mais Items";
$locale['load_end'] = "Carregar do início";
// Actions
$locale['add'] = "Adicionar";
$locale['save'] = "Salvar";
$locale['save_changes'] = "Salvar Alterações";
$locale['save_and_close'] = "Salvar e Fechar";
$locale['save_settings'] = "Salvar Definições";
$locale['settings_updated'] = "Configuração atualizada com sucesso";
$locale['confirm'] = "Confirmar";
$locale['update'] = "Atualizar";
$locale['updated'] = "Atualizado";
$locale['remove'] = "Remover";
$locale['delete'] = "Apagar";
$locale['search'] = "Pesquisar";
$locale['help'] = "Ajuda";
$locale['register'] = "Registar";
$locale['ban'] = "Banir";
$locale['reactivate'] = "Reativar";
$locale['user'] = "Usuário";
$locale['promote'] = "Promover";
$locale['show'] = "Mostrar";
$locale['hide'] = "Ocultar";
$locale['actions'] = "Ações";
$locale['language'] = "Idioma";
$locale['loading'] = "A carregar...";
$locale['options'] = "Opções";
// Persons & Identifiers
$locale['you'] = "Você";
$locale['me'] = "Eu";
$locale['they'] = "Eles";
$locale['we'] = "Nós";
$locale['us'] = "Nós";
$locale['he'] = "Ele";
$locale['she'] = "Ela";
$locale['it'] = "Este";
// Tables
$locale['order'] = "Ordenar";
$locale['sort'] = "Ordenar";
$locale['id'] = "ID";
$locale['title'] = "Título";
$locale['rights'] = "Direitos";
$locale['info'] = "Informação";
$locale['image'] = "Imagem";
// Forms
$locale['choose'] = "Por favor escolha uma...";
$locale['no_opts'] = "Sem seleção";
$locale['root'] = "Como Pai";
$locale['choose-user'] = "Por favor, escolha um Usuário...";
$locale['choose-location'] = "Por favor, selecione uma localização";
$locale['parent'] = "Criar como um Novo Pai..";
$locale['item_order'] = "Ordenar Items";
$locale['status'] = "Estado";
$locale['note'] = "Anotar este item";
$locale['publish'] = "Publicar";
$locale['unpublish'] = "Cancelar publicação";
$locale['published'] = "Publicado";
$locale['unpublished'] = "Não Publicado";
$locale['sticky'] = "Fixo";
$locale['unsticky'] = "Desafixar";
$locale['draft'] = "Rascunho";
$locale['settings'] = "Definições";
$locale['posted'] = "submetido";
$locale['profile'] = "Perfil";
$locale['edit'] = "Editar";
$locale['qedit'] = "Edição rápida";
$locale['view'] = "Visualizar";
$locale['login'] = "Iniciar sessão";
$locale['logout'] = "Terminar Sessão";
$locale['admin-logout'] = "Logout do Admin";
$locale['message'] = "Mensagens Privadas";
$locale['logged'] = "Iniciou sessão como ";
$locale['version'] = "Versão ";
$locale['browse'] = "Procurar ...";
$locale['close'] = "Fechar";
$locale['nopreview'] = "Não há nada para pré-visualizar";
$locale['mark_as'] = "Marcar como";
$locale['preview'] = "Pré-visualizar";
$locale['unpreview'] = "Ocultar visualização";
$locale['custom'] = "Personalizado";
$locale['submit'] = "Enviar";
$locale['submissions'] = "Submissões";
$locale['submit_access'] = "Acesso à página de envio";
$locale['categories'] = "Categorias";
$locale['thumbnail'] = "Thumbnail";
// Alignment
$locale['left'] = "Esquerda";
$locale['center'] = "Centro";
$locale['right'] = "Direita";
// Comments and ratings
$locale['comments'] = "Comentários";
$locale['ratings'] = "Classificação";
$locale['comments_ratings'] = "Comentários e Classificações";
$locale['user_account'] = "Conta de Usuário";
$locale['about'] = "Sobre";
// User status
$locale['online'] = "Online";
$locale['offline'] = "Offline";
// Misc
$locale['max_fs_allowed_ft'] = "Tamanho máx. do arquivo %s / Tipos de arquivo permitidos %s";
// DataTables
$locale['processing_locale'] = "Por favor, aguarde pacientemente enquanto o processamento é realizado...";
$locale['menu_locale'] = "Exibir _MENU_ registros por página"; // Don't translate _MENU_
$locale['zero_locale'] = "Nada encontrado – desculpe";
$locale['result_locale'] = "Exibindo página _PAGE_ of _PAGES_"; // Don't translate _PAGE_ and _PAGES_
$locale['empty_locale'] = "Nenhum registro disponível";
$locale['filter_locale'] = "(Filtered from _MAX_ total records)"; // Don't translate _MAX_
$locale['search_input_locale'] = "Pesquisar registros";
// Timer
$locale['timer_year'] = "ano | anos";
$locale['timer_month'] = "mês|meses";
$locale['timer_day'] = "dia|dias";
$locale['timer_hour'] = "hora|horas";
$locale['timer_minute'] = "minuto|minutos";
$locale['timer_second'] = "segundo|segundos";
$locale['timer'] = "[DAYS] [AGO]";// Não traduza o texto entre []! Altere a ordem apenas se necessário [AGO] [DAYS].
// Palavras para formatação em singular e plural. A quantidade de formas depende do idioma.
$locale['fmt_submission'] = "submissão|submissões";
$locale['fmt_article'] = "artigo|artigos";
$locale['fmt_blog'] = "blog|blogs";
$locale['fmt_comment'] = "comentário|comentários";
$locale['fmt_vote'] = "voto|votos";
$locale['fmt_rating'] = "avaliação|avaliações";
$locale['fmt_day'] = "dia|dias";
$locale['fmt_download'] = "download|downloads";
$locale['fmt_follower'] = "seguidor|seguidores";
$locale['fmt_forum'] = "fórum|fórums";
$locale['fmt_guest'] = "visitante|visitantes";
$locale['fmt_hour'] = "hora|horas";
$locale['fmt_item'] = "item|items";
$locale['fmt_member'] = "usuário|usuários";
$locale['fmt_message'] = "mensagem|mensagens";
$locale['fmt_minute'] = "minuto|minutos";
$locale['fmt_month'] = "mês|meses";
$locale['fmt_news'] = "notícia|notícias";
$locale['fmt_photo'] = "foto|fotos";
$locale['fmt_post'] = "post|posts";
$locale['fmt_question'] = "questão|questões";
$locale['fmt_read'] = "leitura|leituras";
$locale['fmt_second'] = "segundo|segundos";
$locale['fmt_shouts'] = "grito|gritos";
$locale['fmt_thread'] = "tópico|tópicos";
$locale['fmt_user'] = "usuário|usuários";
$locale['fmt_views'] = "visualização|visualizações";
$locale['fmt_weblink'] = "weblink|weblinks";
$locale['fmt_week'] = "semana|semanas";
$locale['fmt_year'] = "ano | anos";
$locale['fmt_points'] = "ponto|pontos";
$locale['fmt_admin'] = "admin|admins";
$locale['fmt_group'] = "grupo|grupos";
$locale['fmt_category'] = "categoria|categorias";
$locale['fmt_review'] = "revisão|revisões";
$locale['fmt_infusion'] = "infusão|infusões";
// include Defender locales
include_once __DIR__."/defender.php";
