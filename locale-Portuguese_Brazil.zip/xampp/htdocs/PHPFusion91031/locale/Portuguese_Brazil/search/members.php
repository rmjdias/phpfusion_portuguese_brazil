<?php
$locale['m400'] = "Usuários";
$locale['m401'] = "Usuário";
$locale['m402'] = "Usuários";
$locale['m403'] = "Os perfis só estão visíveis para úsuários!";
