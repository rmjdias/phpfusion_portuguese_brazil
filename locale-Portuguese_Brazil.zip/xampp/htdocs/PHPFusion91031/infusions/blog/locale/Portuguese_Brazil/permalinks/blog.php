<?php
$locale['pl_blog_title'] = "Blog";
$locale['pl_blog_desc'] = "Ativar Links Permanentes para o Blog no site.";
$locale['pl_tags_001'] = "ID do Item do Blog.";
$locale['pl_tags_002'] = "Título ou Assunto do Item do Blog.";
