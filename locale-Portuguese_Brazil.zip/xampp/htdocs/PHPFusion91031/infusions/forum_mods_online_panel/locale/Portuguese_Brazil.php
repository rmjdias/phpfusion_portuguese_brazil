<?php
$locale['fmp_0100'] = "Usuários do Staff Online Agora";
$locale['fmp_0101'] = "Usuários da Administração";
$locale['fmp_0102'] = "Moderadores Online Agora";
