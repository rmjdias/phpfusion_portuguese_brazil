<?php
$locale['pl_weblinks_title'] = "Links da Web";
$locale['pl_weblinks_desc'] = "Ativar Links Permanentes para Links da Web no Site.";
