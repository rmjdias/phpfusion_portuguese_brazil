<?php
$locale['pl_shoutbox_title'] = "Shoutbox";
$locale['pl_shoutbox_desc'] = "Habilitar Links Permanentes para a Shoutbox no site.";
