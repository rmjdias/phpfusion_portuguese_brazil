<?php
$locale['pl_poll_title'] = "Votação dos Usuários";
$locale['pl_poll_desc'] = "Habilitar Links permanentes para as Votações de Usuários no site.";
