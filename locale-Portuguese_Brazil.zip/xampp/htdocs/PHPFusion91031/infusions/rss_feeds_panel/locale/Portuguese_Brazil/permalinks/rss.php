<?php
$locale['pl_rss_title'] = "RSS Feeds";
$locale['pl_rss_desc'] = "Ativar Links Permanentes para os links para feeds RSS.";
