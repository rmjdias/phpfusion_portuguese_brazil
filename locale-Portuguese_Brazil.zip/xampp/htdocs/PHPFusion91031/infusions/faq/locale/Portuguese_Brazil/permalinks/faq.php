<?php
$locale['pl_faq_cat_title'] = "FAQ's";
$locale['pl_faq_cat_desc'] = "Ativar Links Permanentes para Categorias de FAQ no Site.";
