<?php
$locale['pl_gallery_title'] = "Álbuns de Fotos";
$locale['pl_gallery_desc'] = "Habilitar Links permanentes para os Álbuns de Fotos no site.";
