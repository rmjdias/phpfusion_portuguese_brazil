<?php
$locale['pl_forums_title'] = "Fórums";
$locale['pl_forums_desc'] = "Ativar Links permanentes para os Links do Fórum.";
$locale['pl_tags_001'] = "ID de um Fórum específico";
$locale['pl_tags_002'] = "Título de um Fórum específico.";
