<?php
$locale['pl_articles_title'] = "Artigos";
$locale['pl_articles_desc'] = "Habilitar Links Permanentes para os Artigos no site.";
